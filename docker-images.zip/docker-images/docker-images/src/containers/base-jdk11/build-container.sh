#!/bin/bash
docker build --rm=true --tag=tander-sprint/base-jdk11 .