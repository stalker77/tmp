# CentOS JDK 8 Tomcat 7 Docker image
## Usage
To run docker image

    docker run --detach \
        --publish 8084:8080 --publish 8005:8005 \
        --name centos-java8-tomcat7 \
        --volume /Users/stalker/docker-containers-data/tomcat7-java8/logs:/opt/tomcat/logs \
        --volume /Users/stalker/docker-containers-data/tomcat7-java8/webapps:/opt/tomcat/webapps \
        tander-sprint/centos-java8-tomcat7:latest