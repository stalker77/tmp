#!/bin/bash
docker build --rm=true --tag=tander-sprint/centos-haproxy .