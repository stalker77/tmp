# CentOS HaProxy Docker image
## Usage
To run docker image

    docker run --detach \
        --publish 8081:8080 --publish 8443:443 \
        --name centos-haproxy \
        --volume /Users/stalker/servers/haproxy:/usr/local/etc/haproxy \
        tander-sprint/centos-haproxy:latest