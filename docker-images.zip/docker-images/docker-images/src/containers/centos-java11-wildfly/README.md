# CentOS JDK 11 WildFly Docker image
## Usage
To run docker image

    docker run --detach \
        --publish 8082:8080 --publish 9992:9990 \
        --name centos-java11-wildfly \
        --volume /Users/stalker/docker-containers-data/wildfly-java11/logs:/opt/wildfly/standalone/log \
        --volume /Users/stalker/docker-containers-data/wildfly-java11/deployments:/opt/wildfly/standalone/deployments \
        --volume /Users/stalker/docker-containers-data/wildfly-java11/configuration:/opt/wildfly/standalone/configuration \
        --volume /Users/stalker/docker-containers-data/wildfly-java11/tmp:/opt/wildfly/standalone/tmp \
        --volume /Users/stalker/docker-containers-data/wildfly-java11/modules:/opt/wildfly/modules \
        tander-sprint/centos-java11-wildfly:latest