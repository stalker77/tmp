#!/bin/bash
docker build --rm=true --tag=tander-sprint/centos-java8-wildfly .