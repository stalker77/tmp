# CentOS JDK 8 WildFly Docker image
## Usage
To run docker image

    docker run --detach \
        --publish 8081:8080 --publish 9991:9990 \
        --name centos-java8-wildfly \
        --volume /Users/stalker/docker-containers-data/wildfly-java8/logs:/opt/wildfly/standalone/log \
        --volume /Users/stalker/docker-containers-data/wildfly-java8/deployments:/opt/wildfly/standalone/deployments \
        --volume /Users/stalker/docker-containers-data/wildfly-java8/configuration:/opt/wildfly/standalone/configuration \
        --volume /Users/stalker/docker-containers-data/wildfly-java8/tmp:/opt/wildfly/standalone/tmp \
        --volume /Users/stalker/docker-containers-data/wildfly-java8/modules:/opt/wildfly/modules \
        tander-sprint/centos-java8-wildfly:latest