#!/bin/bash
docker build --rm=true --tag=tander-sprint/centos-java7-tomcat7 .