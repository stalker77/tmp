
kubectl autoscale deployment kubia --cpu-percent=30 --min=1 --max=5

