package ru.dobrokvashinevgeny.research.microservices.infrastructure;

import org.jboss.resteasy.core.Dispatcher;
import org.jboss.resteasy.mock.*;
import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.microservices.infrastructure.resources.*;
import ru.dobrokvashinevgeny.test.infrastructure.resources.*;

import javax.ws.rs.core.*;
import java.nio.charset.StandardCharsets;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static ru.dobrokvashinevgeny.research.microservices.infrastructure.resources.AdditionResource.ADDITION_RESOURCE_PATH;
import static ru.dobrokvashinevgeny.research.microservices.infrastructure.resources.AdditionResource.HEALTH_RESOURCE_PATH;
import static ru.dobrokvashinevgeny.test.infrastructure.resources.ObjectToJsonConverter.toJson;

class AdditionResourceIntegrationTest {
	private static final MediaType APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE =
		new MediaType("application", "json", StandardCharsets.UTF_8.name().toLowerCase());
	private static final Response.Status HTTP_STATUS_OK = Response.Status.OK;
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final int SUM_OF_ADDENDS = FIRST_ADDEND + SECOND_ADDEND;
	private static final JaxbAddendsDesc VALID_JAXB_ADDENDS_DESC = new JaxbAddendsDesc(FIRST_ADDEND, SECOND_ADDEND);
	private static final JaxbAdditionResultDesc VALID_JAXB_ADDITION_RESULT_DESC = new JaxbAdditionResultDesc(SUM_OF_ADDENDS);

	private MockRequestToResource requestToResource;

	@BeforeEach
	void setUp() {
		AdditionResource additionResource = new AdditionResource();

		Dispatcher dispatcher = MockDispatcherFactory.createDispatcher();
		requestToResource = new MockRequestToResource(dispatcher);
		dispatcher.getRegistry().addSingletonResource(additionResource, ResourcesBootstrap.RESOURCES_BASE_PATH);
	}

	@Test
	void returnSumOfTwoAddends() throws Exception {
		MockHttpRequest convertRequest = new RequestBuilder()
			.postRequestTo(ResourcesBootstrap.RESOURCES_BASE_PATH + "/" + ADDITION_RESOURCE_PATH)
			.acceptMediaType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(toJson(VALID_JAXB_ADDENDS_DESC))
			.build();

		ComparableMockHttpResponse expectedConvertResponse = new ResponseBuilder()
			.httpStatus(HTTP_STATUS_OK)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(toJson(VALID_JAXB_ADDITION_RESULT_DESC))
			.build();


		ComparableMockHttpResponse convertResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(convertRequest));


		assertThat(convertResponse, equalTo(expectedConvertResponse));
	}

	@Test
	void returnOkOnHealth() throws Exception {
		MockHttpRequest healthRequest = new RequestBuilder()
			.postRequestTo(ResourcesBootstrap.RESOURCES_BASE_PATH + "/" + ADDITION_RESOURCE_PATH + "/" + HEALTH_RESOURCE_PATH)
			.build();

		ComparableMockHttpResponse expectedHealthResponse = new ResponseBuilder()
			.httpStatus(HTTP_STATUS_OK)
			.build();


		ComparableMockHttpResponse healthResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(healthRequest));


		assertThat(healthResponse, equalTo(expectedHealthResponse));
	}
}