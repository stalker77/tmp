package ru.dobrokvashinevgeny.research.microservices.infrastructure;

import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.microservices.infrastructure.resources.*;

import javax.ws.rs.client.Client;
import java.net.URI;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static ru.dobrokvashinevgeny.research.microservices.infrastructure.resources.AdditionResource.ADDITION_RESOURCE_PATH;

class AdditionResourceEndToEndTest {
	private static final String ADDITION_SERVICE_HTTP_SCHEME = "http";
	private static final int CONNECT_TIMEOUT = 1 * 1000;
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final int SUM_OF_ADDENDS = FIRST_ADDEND + SECOND_ADDEND;

	private static Client additionServiceClient;

	/*@Rule
	public GenericContainer additionServiceContainer = new GenericContainer(
		new ImageFromDockerfile()
			.withDockerfile(Paths.get("target/deployment/docker"))
	).waitingFor(Wait.forHttp("/"));*/

	@BeforeAll
	static void setUp() throws Exception {
		final ResteasyClientBuilder clientBuilder =
			new ResteasyClientBuilder().httpEngine(
				new ClientHttpEngineProducer(
					null, URI.create(ADDITION_SERVICE_HTTP_SCHEME + "://test"),
					CONNECT_TIMEOUT, "",
					null
				).createClientHttpEngineBy()
			);

		additionServiceClient = clientBuilder.build();
	}

	@AfterAll
	static void tearDown() {
		additionServiceClient.close();
	}

	@Test
	void returnSumOfTwoAddends() throws Exception {
		URI additionServiceUri =
			URI.create(
				ADDITION_SERVICE_HTTP_SCHEME + "://" + "localhost:8085/"
//				+ additionServiceContainer.getContainerIpAddress()
//				+ ":" + additionServiceContainer.getMappedPort(8080)
				+ ResourcesBootstrap.RESOURCES_BASE_PATH + "/" + ADDITION_RESOURCE_PATH
			);

		RestClientService additionServiceRestClientService = new RestClientService(additionServiceClient);

		JaxbAdditionResultDesc expectedAdditionResult = new JaxbAdditionResultDesc(SUM_OF_ADDENDS);


		JaxbAdditionResultDesc additionResult = additionServiceRestClientService.getJsonPostRequestResultFor(
			additionServiceUri,
			new JaxbAddendsDesc(FIRST_ADDEND, SECOND_ADDEND),
			JaxbAdditionResultDesc.class
		);


		assertThat(additionResult, equalTo(expectedAdditionResult));
	}
}