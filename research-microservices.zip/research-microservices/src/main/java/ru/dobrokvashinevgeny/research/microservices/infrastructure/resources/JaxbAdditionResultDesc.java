/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.microservices.infrastructure.resources;

import java.util.Objects;

public class JaxbAdditionResultDesc {
	private int sumOfAddends;

	public JaxbAdditionResultDesc() { /*NOP FOR JAXB SPEC*/ }

	public JaxbAdditionResultDesc(int sumOfAddends) {
		this.sumOfAddends = sumOfAddends;
	}

	public int getSumOfAddends() {
		return sumOfAddends;
	}

	public void setSumOfAddends(int sumOfAddends) {
		this.sumOfAddends = sumOfAddends;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		JaxbAdditionResultDesc that = (JaxbAdditionResultDesc) o;
		return getSumOfAddends() == that.getSumOfAddends();
	}

	@Override
	public int hashCode() {
		return Objects.hash(getSumOfAddends());
	}

	@Override
	public String toString() {
		return "JaxbAdditionResultDesc{" +
			"sumOfAddends=" + sumOfAddends +
			'}';
	}
}