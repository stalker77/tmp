/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.microservices.infrastructure.resources;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path(AdditionResource.ADDITION_RESOURCE_PATH)
public class AdditionResource {
	public static final String ADDITION_RESOURCE_PATH = "addition";
	public static final String HEALTH_RESOURCE_PATH = "health";

	@POST
	@Consumes(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=utf-8;")
	@Produces(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=utf-8;")
	public JaxbAdditionResultDesc getAdditionResult(JaxbAddendsDesc jaxbAddendsDesc) {
		return new JaxbAdditionResultDesc(
			jaxbAddendsDesc.getFirstAddend() + jaxbAddendsDesc.getSecondAddend()
		);
	}

	@Path(HEALTH_RESOURCE_PATH)
	@POST
	public Response getHealth() {
		return Response.ok().build();
	}
}