/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.microservices.infrastructure.resources;

public class JaxbAddendsDesc {
	private int firstAddend;
	private int secondAddend;

	public JaxbAddendsDesc() { /*NOP FOR JAXB SPEC*/ }

	public JaxbAddendsDesc(int firstAddend, int secondAddend) {
		this.firstAddend = firstAddend;
		this.secondAddend = secondAddend;
	}

	public int getFirstAddend() {
		return firstAddend;
	}

	public void setFirstAddend(int firstAddend) {
		this.firstAddend = firstAddend;
	}

	public int getSecondAddend() {
		return secondAddend;
	}

	public void setSecondAddend(int secondAddend) {
		this.secondAddend = secondAddend;
	}
}