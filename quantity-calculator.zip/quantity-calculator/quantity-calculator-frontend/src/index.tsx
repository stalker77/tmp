import QuantityCalculatorApp from "./main/quantitycalculator/QuantityCalculatorApp";

const quantityCalculatorApp : QuantityCalculatorApp = new QuantityCalculatorApp();
quantityCalculatorApp.run();

