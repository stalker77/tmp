import QuantityCalculatorApp from "../../main/quantitycalculator/QuantityCalculatorApp";
import QuantityCalculatorPresenter from "../../main/quantitycalculator/interfaceadapters/QuantityCalculatorPresenter";
import UnitService from "../../main/quantitycalculator/services/UnitService";

describe('QuantityCalculatorApp', () => {
    it('successfully run application', () => {
        const quantityCalculatorApp: QuantityCalculatorApp = new QuantityCalculatorApp();

        const QuantityCalculatorPresenterMock: QuantityCalculatorPresenter = jest.fn(() => ({
            showView: jest.fn(),
        }));
        const quantityCalculatorPresenterMock = new QuantityCalculatorPresenterMock();
        quantityCalculatorApp.setQuantityCalculatorPresenter(quantityCalculatorPresenterMock);

        const UnitServiceMock: UnitService = jest.fn(() => ({
            getListOfExistingUnitTypes: jest.fn(),
        }));
        const unitServiceMock = new UnitServiceMock();
        quantityCalculatorApp.setUnitService(unitServiceMock);


        quantityCalculatorApp.run();


        expect(unitServiceMock.getListOfExistingUnitTypes).toHaveBeenCalledTimes(1);
        expect(quantityCalculatorPresenterMock.showView).toHaveBeenCalledTimes(1);
    });
});