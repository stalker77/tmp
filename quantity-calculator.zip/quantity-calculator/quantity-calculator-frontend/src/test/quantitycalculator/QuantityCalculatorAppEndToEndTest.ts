import puppeteer from 'puppeteer';
import {ElementHandle, Browser, Page} from "puppeteer";

describe('QuantityCalculatorApp', () => {
    const PUPPETEER_HEADLESS_MODE: boolean = false;
    const PUPPETEER_OPERATIONS_SLOWDOWN_IN_MSEC: number = 200;
    const PUPPETEER_PAGE_WIDTH_IN_PIXELS: number = 800;
    const PUPPETEER_PAGE_HEIGHT_IN_PIXELS: number = 600;
    const PUPPETEER_EMULATED_USER_AGENT: string = '';
    const ASYNC_TEST_TIMEOUT: number = 16000;
    const QUANTITY_CALCULATOR_APP_URL: string = 'http://localhost:3000/';

    const QUANTITY_UNIT_TYPE_VALUE: string = 'speed';
    const ENTER_SOURCE_QUANTITY_AMOUNT: number = 10;
    const SOURCE_QUANTITY_UNIT: string = '3';
    const DESTINATION_QUANTITY_UNIT: string = '2';
    const EXPECTED_DESTINATION_QUANTITY_AMOUNT: number = 10;

    let browser: Browser;
    let page: Page;

    beforeAll(async () => {
        browser = await puppeteer.launch(
            {
                headless: PUPPETEER_HEADLESS_MODE, // headless mode set to false so browser opens up with visual feedback
                slowMo: PUPPETEER_OPERATIONS_SLOWDOWN_IN_MSEC, // how slow actions should be
            }
        );

        // creates a new page in the opened browser
        page = await browser.newPage();
        await page.emulate({
            viewport: {
                width: PUPPETEER_PAGE_WIDTH_IN_PIXELS,
                height: PUPPETEER_PAGE_HEIGHT_IN_PIXELS
            },
            userAgent: PUPPETEER_EMULATED_USER_AGENT
        });
    }, ASYNC_TEST_TIMEOUT);

    it('successfully convert source quantity to destination unit', async () => {
        await page.goto(QUANTITY_CALCULATOR_APP_URL);

        await selectQuantityUnitTypeValue(QUANTITY_UNIT_TYPE_VALUE);

        await enterSourceQuantityAmountBy(ENTER_SOURCE_QUANTITY_AMOUNT);

        await selectSourceQuantityUnitBy(SOURCE_QUANTITY_UNIT);

        await selectDestinationQuantityUnitBy(DESTINATION_QUANTITY_UNIT);


        await clickOnButtonByName('convertQuantity');


        expect(await getDestinationQuantityAmount()).toBe(EXPECTED_DESTINATION_QUANTITY_AMOUNT);
    }, ASYNC_TEST_TIMEOUT);

    async function selectQuantityUnitTypeValue(unitTypeValue: string) {
        await selectValueFromSelectInputBy('quantityUnitType', unitTypeValue)
    }

    async function selectValueFromSelectInputBy(selectComponentName: string, value: string) {
        const addendInput: ElementHandle
            = await page.waitForSelector('input[name="' + selectComponentName + '"]');
        await addendInput.select(value);
    }

    async function selectSourceQuantityUnitBy(unitValue: string) {
        await selectValueFromSelectInputBy('sourceQuantityUnit', unitValue);
    }

    async function selectDestinationQuantityUnitBy(unitValue: string) {
        await selectValueFromSelectInputBy('destinationQuantityUnit', unitValue);
    }

    async function enterSourceQuantityAmountBy(amount: number) {
        const numberEditor: ElementHandle = await page.waitForSelector('input[name="sourceQuantityAmount"]');
        await numberEditor.click();
        await page.keyboard.type(String(amount));
    }

    async function clickOnButtonByName(buttonName: string) {
        const calculateSumButton: ElementHandle
            = await page.waitForSelector('button[name="' + buttonName + '"]');
        await calculateSumButton.click();
    }

    async function getDestinationQuantityAmount(): Promise<number> {
        const destQuantityAmountInput: ElementHandle
            = await page.waitForSelector('input[name="destinationQuantityAmount"]');

        return Number(
            await page.evaluate(destQuantityAmountInput => destQuantityAmountInput.value, destQuantityAmountInput)
        );
    }

    afterAll(() => {
        browser.close()
    })
});