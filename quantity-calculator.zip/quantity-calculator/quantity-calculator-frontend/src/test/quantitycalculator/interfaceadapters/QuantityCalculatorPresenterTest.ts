import QuantityCalculatorPresenter from "../../../main/quantitycalculator/interfaceadapters/QuantityCalculatorPresenter";
import QuantityCalculatorView from "../../../main/quantitycalculator/interfaceadapters/QuantityCalculatorView";

describe('QuantityCalculatorPresenter', () => {
    it('successfully show view', () => {
        const quantityCalculatorViewMock: QuantityCalculatorView = {
            show: jest.fn(),
        };

        const formPresenter: QuantityCalculatorPresenter = new QuantityCalculatorPresenter(quantityCalculatorViewMock);


        formPresenter.showView();


        expect(quantityCalculatorViewMock.show).toHaveBeenCalledTimes(1);
    });
});