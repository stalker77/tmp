import UnitTypeNamesDesc from "./UnitTypeNamesDesc";

export default class UnitService {
    getListOfExistingUnitTypes(): UnitTypeNamesDesc {
        return new UnitTypeNamesDesc();
    }
}