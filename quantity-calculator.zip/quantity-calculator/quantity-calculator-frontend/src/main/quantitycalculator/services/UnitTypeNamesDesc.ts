export default class UnitTypeNamesDesc {

}