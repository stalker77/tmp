export default interface QuantityCalculatorView {
    show(): void;
}