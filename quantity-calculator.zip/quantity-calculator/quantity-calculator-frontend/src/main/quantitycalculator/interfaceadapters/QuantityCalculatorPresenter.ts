import QuantityCalculatorView from "./QuantityCalculatorView";

export default class QuantityCalculatorPresenter {
    private readonly quantityCalculatorView: QuantityCalculatorView;

    constructor(quantityCalculatorView: QuantityCalculatorView) {
        this.quantityCalculatorView = quantityCalculatorView;
    }

    showView() {
        this.quantityCalculatorView.show();
    }
}