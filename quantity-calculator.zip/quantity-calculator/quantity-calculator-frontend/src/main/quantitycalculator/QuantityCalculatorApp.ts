import QuantityCalculatorPresenter from "./interfaceadapters/QuantityCalculatorPresenter";
import UnitService from "./services/UnitService";
import AntdQuantityCalculatorView from "./presentation/AntdQuantityCalculatorView";

export default class QuantityCalculatorApp {
    private externalQuantityCalculatorPresenter?: QuantityCalculatorPresenter;

    run() {
        const quantityCalculatorPresenter: QuantityCalculatorPresenter = this.quantityCalculatorPresenter();

        quantityCalculatorPresenter.showView();
    }

    private quantityCalculatorPresenter(): QuantityCalculatorPresenter {
        if (this.externalQuantityCalculatorPresenter === undefined) {
            return new QuantityCalculatorPresenter(new AntdQuantityCalculatorView());
        } else {
            return this.externalQuantityCalculatorPresenter as QuantityCalculatorPresenter;
        }

    }

    setQuantityCalculatorPresenter(quantityCalculatorPresenter: QuantityCalculatorPresenter) {
        this.externalQuantityCalculatorPresenter = quantityCalculatorPresenter;
    }

    setUnitService(unitService: UnitService) {

    }
}