import QuantityCalculatorView from "../interfaceadapters/QuantityCalculatorView";

export default class AntdQuantityCalculatorView implements QuantityCalculatorView {
    show(): void {
    }
}