package org.acme.events;

import io.quarkus.runtime.StartupEvent;
import org.jboss.weld.junit5.*;
import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence.*;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.mockito.Mockito.mock;

@EnableWeld
class QuantityCalculatorServiceBootstrapIntegrationTest {
	@WeldSetup
	public WeldInitiator weldInitiator = WeldInitiator.from(
		InMemoryUnits.class, InMemoryUnitConversionRatios.class, InMemoryUnitTypes.class,
		QuantityCalculatorServiceBootstrap.class
	).activate(ApplicationScoped.class).inject(this).build();

	@Inject
	private QuantityCalculatorServiceBootstrap quantityCalculatorServiceBootstrap;

	@Inject
	private InMemoryUnits inMemoryUnits;

	@Inject
	private InMemoryUnitConversionRatios inMemoryUnitConversionRatios;

	@Inject
	private InMemoryUnitTypes inMemoryUnitTypes;

	@BeforeEach
	void setUp() {
		quantityCalculatorServiceBootstrap.onStart(mock(StartupEvent.class));
	}

	@Test
	void successfullyInjectQuantityCalculatorServiceBootstrap() {
		assertThat("quantityCalculatorServiceBootstrap", quantityCalculatorServiceBootstrap, is(notNullValue()));
	}

	@Test
	void correctlyLoadUnits() {
		assertThat(inMemoryUnits.size(), equalTo(7));
	}

	@Test
	void correctlyLoadUnitConversionRatios() {
		assertThat(inMemoryUnitConversionRatios.size(), equalTo(1));
	}

	@Test
	void correctlyLoadUnitTypes() {
		assertThat(inMemoryUnitTypes.size(), equalTo(5));
	}
}