/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import org.jboss.resteasy.mock.MockHttpResponse;

import javax.ws.rs.core.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class ResponseBuilder {
	private Response.Status httStatus;
	private String contentTypeString;
	private MediaType contentType;
	private String contentDisposition;
	private String content;
	private String contentEncoding;

	public ResponseBuilder httpStatus(Response.Status httpStatus) {
		this.httStatus = httpStatus;

		return this;
	}

	public ResponseBuilder contentEncoding(String encoding) {
		this.contentEncoding = encoding;

		return this;
	}

	public ResponseBuilder contentType(String contentType) {
		this.contentTypeString = contentType;

		return this;
	}

	public ResponseBuilder contentType(MediaType contentType) {
		this.contentType = contentType;

		return this;
	}

	public ResponseBuilder contentDisposition(String contentDisposition) {
		this.contentDisposition = contentDisposition;

		return this;
	}

	public ResponseBuilder content(String content) {
		this.content = content;

		return this;
	}

	public ComparableMockHttpResponse build() {
		ByteArrayOutputStream outBuffer = new ByteArrayOutputStream();

		if (content != null) {
			try {
				outBuffer.write(content.getBytes(StandardCharsets.UTF_8));
			} catch (IOException e) { /* NOP */ }
		}

		final MockHttpResponse mockHttpResponse = new MockHttpResponse() {
			@Override
			public void setOutputStream(OutputStream os) {
				super.baos = outBuffer;
			}
		};

		mockHttpResponse.setStatus(httStatus.getStatusCode());

		if (contentEncoding != null) {
			mockHttpResponse.getOutputHeaders().add("Content-Encoding", contentEncoding);
		}

		if (contentTypeString != null) {
			mockHttpResponse.getOutputHeaders().add("Content-Type", contentTypeString);
		} else if (contentType != null) {
			mockHttpResponse.getOutputHeaders().add("Content-Type", contentType);
		}

		if (contentDisposition != null) {
			mockHttpResponse.getOutputHeaders().add("Content-Disposition", contentDisposition);
		}

		if (content != null) {
			mockHttpResponse.setOutputStream(outBuffer);
		}

		return new ComparableMockHttpResponse(mockHttpResponse);
	}
}