/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.Units;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

import static org.mockito.Mockito.mock;

@ApplicationScoped
public class UnitsMockProducer {
	private Units units = mock(Units.class);

	@Produces
	Units units() {
		return units;
	}
}