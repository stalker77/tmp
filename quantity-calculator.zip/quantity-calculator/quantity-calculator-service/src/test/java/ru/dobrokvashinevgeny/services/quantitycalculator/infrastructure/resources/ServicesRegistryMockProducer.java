/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources;

import ru.dobrokvashinevgeny.services.quantitycalculator.services.ServicesRegistry;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

import static org.mockito.Mockito.mock;

@ApplicationScoped
public class ServicesRegistryMockProducer {
	private ServicesRegistry servicesRegistry = mock(ServicesRegistry.class);

	@Produces
	ServicesRegistry servicesRegistry() {
		return servicesRegistry;
	}
}