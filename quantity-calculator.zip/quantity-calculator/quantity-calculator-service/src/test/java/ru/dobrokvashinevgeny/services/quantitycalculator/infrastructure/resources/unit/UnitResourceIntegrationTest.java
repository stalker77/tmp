package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.unit;

import org.jboss.resteasy.mock.*;
import org.jboss.resteasy.spi.Dispatcher;
import org.jboss.weld.junit5.*;
import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.ServicesRegistryMockProducer;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.ServicesRegistry;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.unit.*;

import javax.inject.Inject;
import javax.ws.rs.core.*;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.ResourcesBootstrap.RESOURCES_BASE_PATH;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.unit.UnitResource.*;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services.ObjectToJsonConverter.toJson;

@EnableWeld
class UnitResourceIntegrationTest {
	private static final Response.Status HTTP_STATUS_OK = Response.Status.OK;
	private static final MediaType APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE =
		new MediaType("application", "json", StandardCharsets.UTF_8.name().toLowerCase());
	private static final String UNIT_TYPE_NAME = "Скорость";
	private static final String UNIT_TYPE_ID_VALUE = "speed";
	private static final String UNIT_FORMATTED_VALUE_ONE = "км/с";
	private static final String UNIT_FORMATTED_VALUE_TWO = "м/с";
	private static final String EXCEPTION_CONTENT_ENCODING = "UTF-8";

	private MockRequestToResource requestToResource;

	@WeldSetup
	public WeldInitiator weldInitiator = WeldInitiator.from(
		UnitResource.class, ServicesRegistryMockProducer.class
	).build();

	@Inject
	private UnitResource unitResource;

	@Inject
	private ServicesRegistry servicesRegistry;

	private UnitService unitService;

	@BeforeEach
	void setUp() {
		Dispatcher dispatcher = MockDispatcherFactory.createDispatcher();
		requestToResource = new MockRequestToResource(dispatcher);
		dispatcher.getRegistry().addSingletonResource(unitResource);
		dispatcher.getProviderFactory().registerProvider(UnitResourceExceptionMapper.class);

		unitService = mock(UnitService.class);
	}

	@Test
	void returnListOfExistingUnitTypes() throws Exception {
		given(unitService.getUnitTypeNames()).willReturn(new UnitTypeNamesDesc(List.of(UNIT_TYPE_NAME)));
		given(servicesRegistry.unitService()).willReturn(unitService);

		MockHttpRequest listOfExistingUnitTypesRequest = new RequestBuilder()
			.getRequestTo(RESOURCES_BASE_PATH + "/" + UNIT_RESOURCE_PATH + "/" + TYPE_PATH)
			.acceptMediaType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.build();

		ComparableMockHttpResponse expectedListOfExistingUnitTypesResponse = new ResponseBuilder()
			.httpStatus(HTTP_STATUS_OK)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(toJson(new JaxbUnitTypeNamesDesc(List.of(UNIT_TYPE_NAME))))
			.build();


		ComparableMockHttpResponse listOfExistingUnitTypesResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(listOfExistingUnitTypesRequest));


		assertThat(listOfExistingUnitTypesResponse, equalTo(expectedListOfExistingUnitTypesResponse));
	}

	@Test
	void returnListOfUnitFormattedValuesOfRequestedTypeId() throws Exception {
		given(unitService.getUnitFormattedValuesOfUnitTypeId(UNIT_TYPE_ID_VALUE))
			.willReturn(new UnitFormattedValuesDesc(List.of(UNIT_FORMATTED_VALUE_ONE, UNIT_FORMATTED_VALUE_TWO)));
		given(servicesRegistry.unitService()).willReturn(unitService);

		MockHttpRequest listOfUnitFormattedValuesRequest = new RequestBuilder()
			.getRequestTo(
				RESOURCES_BASE_PATH + "/" + UNIT_RESOURCE_PATH + "?" + UNIT_TYPE_ID + "=" + UNIT_TYPE_ID_VALUE
			)
			.acceptMediaType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.build();

		ComparableMockHttpResponse expectedListOfUnitFormattedValuesResponse = new ResponseBuilder()
			.httpStatus(HTTP_STATUS_OK)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(
				toJson(new JaxbUnitFormattedValuesDesc(List.of(UNIT_FORMATTED_VALUE_ONE, UNIT_FORMATTED_VALUE_TWO)))
			)
			.build();


		ComparableMockHttpResponse listOfUnitFormattedValuesResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(listOfUnitFormattedValuesRequest));


		assertThat(listOfUnitFormattedValuesResponse, equalTo(expectedListOfUnitFormattedValuesResponse));
	}

	@Test
	void returnErrorCodeDuringReturnListOfUnitFormattedValuesOfRequestedTypeIdWhenUnitServiceFailed() throws Exception {
		given(unitService.getUnitFormattedValuesOfUnitTypeId(UNIT_TYPE_ID_VALUE))
			.willThrow(UnitServiceException.class);
		given(servicesRegistry.unitService()).willReturn(unitService);

		MockHttpRequest listOfUnitFormattedValuesRequest = new RequestBuilder()
			.getRequestTo(
				RESOURCES_BASE_PATH + "/" + UNIT_RESOURCE_PATH + "?" + UNIT_TYPE_ID + "=" + UNIT_TYPE_ID_VALUE
			)
			.acceptMediaType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.build();

		ComparableMockHttpResponse expectedListOfUnitFormattedValuesErrorResponse = new ResponseBuilder()
			.httpStatus(Response.Status.BAD_REQUEST)
			.contentEncoding(EXCEPTION_CONTENT_ENCODING)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(UnitServiceException.class.getCanonicalName() + "\n Подробная информация в логе.")
			.build();


		ComparableMockHttpResponse listOfUnitFormattedValuesResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(listOfUnitFormattedValuesRequest));


		assertThat(listOfUnitFormattedValuesResponse, equalTo(expectedListOfUnitFormattedValuesErrorResponse));
	}
}