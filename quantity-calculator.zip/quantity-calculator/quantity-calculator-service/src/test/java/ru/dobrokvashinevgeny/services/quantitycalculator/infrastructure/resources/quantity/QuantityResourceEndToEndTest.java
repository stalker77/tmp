package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity;

import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services.*;
import ru.dobrokvashinevgeny.test.infrastructure.services.ConfigProducerFromResourcesPropertiesFile;

import javax.ws.rs.client.*;
import java.net.URI;
import java.util.Properties;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.ResourcesBootstrap.RESOURCES_BASE_PATH;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity.QuantityResource.HEALTH_RESOURCE_PATH;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity.QuantityResource.QUANTITY_CALCULATOR_RESOURCE_PATH;

@Disabled
class QuantityResourceEndToEndTest {
	private static final String QUANTITY_CALCULATOR_SERVICE_HTTP_SCHEME = "http";
	private static final int CONNECT_TIMEOUT = 1 * 1000;
	private static final int HTTP_STATUS_OK = 200;
	private static final String FROM_UNIT_ID = "м";
	private static final String TO_UNIT_ID = "км";
	private static final double AMOUNT = 5;

	private static Client quantityCalculatorServiceClient;
	private static RestClientService quantityCalculatorServiceRestClientService;
	private static Properties endToEndConfig;

	@BeforeAll
	static void setUp() throws Exception {
		var configProducerFromResourcesPropertiesFile = new ConfigProducerFromResourcesPropertiesFile();

		endToEndConfig = configProducerFromResourcesPropertiesFile.produceConfigBy(
			"endToEndTestsConfig.properties");

		final var clientHttpEngineProducer = new ClientHttpEngineProducer(
			null, URI.create(QUANTITY_CALCULATOR_SERVICE_HTTP_SCHEME + "://test"),
			CONNECT_TIMEOUT, "",
			null
		);
		final var clientHttpEngineBy = clientHttpEngineProducer.createClientHttpEngineBy();
		final var clientBuilder = ((ResteasyClientBuilder) ClientBuilder.newBuilder()).httpEngine(
			clientHttpEngineBy
		);

		quantityCalculatorServiceClient = clientBuilder.build();

		quantityCalculatorServiceRestClientService = new RestClientService(quantityCalculatorServiceClient);
	}

	@AfterAll
	static void tearDown() {
		quantityCalculatorServiceClient.close();
	}

	@Test
	void returnsConvertedQuantityDescToSpecifiedUnitFromSpecifiedQuantityDesc() throws Exception {
		final String quantityCalculatorServiceHost = endToEndConfig.getProperty("services.quantityCalculator.host");
		final String quantityCalculatorServicePort = endToEndConfig.getProperty("services.quantityCalculator.port");
		final String quantityCalculatorServiceResourceAddress = String.format("%s://%s:%s/%s/%s", QUANTITY_CALCULATOR_SERVICE_HTTP_SCHEME,
			quantityCalculatorServiceHost, quantityCalculatorServicePort, RESOURCES_BASE_PATH, QUANTITY_CALCULATOR_RESOURCE_PATH);
		waitForQuantityCalculatorServiceReadyBy(URI.create(quantityCalculatorServiceResourceAddress + "/" + HEALTH_RESOURCE_PATH), 60);

		var expectedConvertResult = new JaxbQuantityDesc(AMOUNT, TO_UNIT_ID);

		JaxbQuantityDesc convertResult = quantityCalculatorServiceRestClientService.getJsonPostRequestResultFor(
			URI.create(quantityCalculatorServiceResourceAddress),
			new JaxbConvertQuantityOperationDesc(AMOUNT, FROM_UNIT_ID, TO_UNIT_ID),
			JaxbQuantityDesc.class
		);


		assertThat(convertResult, equalTo(expectedConvertResult));
	}

	private void waitForQuantityCalculatorServiceReadyBy(URI additionServiceReadyCheckUri, int waitTimeoutInSeconds)
		throws RestClientServiceException, InterruptedException {

		int httpStatusCode = getHttpStatusCode(additionServiceReadyCheckUri);

		int timeout = waitTimeoutInSeconds;
		while (httpStatusCode != HTTP_STATUS_OK && timeout-- > 0) {
			Thread.sleep(1000);

			httpStatusCode = getHttpStatusCode(additionServiceReadyCheckUri);
		}

		if (httpStatusCode != HTTP_STATUS_OK) {
			throw new RestClientServiceException("Service not ready.");
		}
	}

	private int getHttpStatusCode(URI additionServiceReadyCheckUri) {
		int httpStatusCode = -1;
		try {
			httpStatusCode = quantityCalculatorServiceRestClientService.checkGetHealthRequestFor(additionServiceReadyCheckUri);
		} catch (RestClientServiceException e) { /* NOP */ }

		return httpStatusCode;
	}
}