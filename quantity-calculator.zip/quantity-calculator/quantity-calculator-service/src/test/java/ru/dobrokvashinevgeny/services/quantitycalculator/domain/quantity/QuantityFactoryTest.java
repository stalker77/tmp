package ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity;

import org.junit.jupiter.api.Test;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

class QuantityFactoryTest {
	private static final int QUANTITY_AMOUNT = 7;
	private static final String UNIT_ID = "км";
	private static final String NOT_EXISTS_UNIT_ID = "not exists";

	@Test
	void createQuantityBySpecifiedParameters() throws Exception {
		Unit unit = mock(Unit.class);
		Units units = mock(Units.class);
		given(units.unitOfId(UNIT_ID)).willReturn(unit);
		QuantityFactory quantityFactory = new QuantityFactory(units);

		Quantity expectedQuantity = new Quantity(QUANTITY_AMOUNT, unit);


		Quantity quantity = quantityFactory.createQuantityBy(QUANTITY_AMOUNT, UNIT_ID);


		assertThat(quantity, equalTo(expectedQuantity));
	}

	@Test
	void throwExceptionWhenSpecifiedNotExistsUnitId() throws Exception {
		Units units = mock(Units.class);
		given(units.unitOfId(NOT_EXISTS_UNIT_ID)).willThrow(UnitNotFoundException.class);
		QuantityFactory quantityFactory = new QuantityFactory(units);


		assertThrows(
			QuantityFactoryException.class,
			() -> quantityFactory.createQuantityBy(QUANTITY_AMOUNT, NOT_EXISTS_UNIT_ID)
		);
	}
}