package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.Unit;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

class InMemoryUnitConversionRatiosTest {
	private static final int ZERO_SIZE = 0;
	private static final Unit FROM_UNIT_ID = mock(Unit.class);
	private static final Unit TO_UNIT_ID = mock(Unit.class);
	private static final int ONE = 1;
	private static final double RATIO_VALUE = 0.1;

	@Test
	void hasZeroSizeOfNewInstance() {
		var unitConversionRatios = new InMemoryUnitConversionRatios();


		assertThat(unitConversionRatios.size(), equalTo(ZERO_SIZE));
	}

	@Test
	void increaseSizeByOneAfterAddNewUnitConversionRatio() {
		var unitConversionRatios = new InMemoryUnitConversionRatios();


		unitConversionRatios.add(new UnitConversionRatio(FROM_UNIT_ID, TO_UNIT_ID, RATIO_VALUE));


		assertThat(unitConversionRatios.size(), equalTo(ONE));
	}

	@Test
	void returnAddedUnitConversionRatioByFromUnitIdAndToUnit() throws Exception {
		var unitConversionRatios = new InMemoryUnitConversionRatios();

		final var unitConversionRatio = new UnitConversionRatio(FROM_UNIT_ID, TO_UNIT_ID, RATIO_VALUE);
		unitConversionRatios.add(unitConversionRatio);


		assertThat(unitConversionRatios.conversionRatioOf(FROM_UNIT_ID, TO_UNIT_ID), equalTo(unitConversionRatio));
	}

	@Test
	void throwExceptionWhenUnitNotFound() {
		var unitConversionRatios = new InMemoryUnitConversionRatios();


		assertThrows(
			ConversionRatioNotFoundException.class,
			() -> unitConversionRatios.conversionRatioOf(FROM_UNIT_ID, TO_UNIT_ID)
		);
	}
}