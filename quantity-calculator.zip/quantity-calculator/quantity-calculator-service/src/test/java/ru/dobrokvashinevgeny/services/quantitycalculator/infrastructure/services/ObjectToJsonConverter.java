/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectToJsonConverter {
	private ObjectToJsonConverter() { /* NOP */ }

	public static String toJson(Object objectValue) throws JsonProcessingException {
		return new ObjectMapper().writeValueAsString(objectValue);
	}
}