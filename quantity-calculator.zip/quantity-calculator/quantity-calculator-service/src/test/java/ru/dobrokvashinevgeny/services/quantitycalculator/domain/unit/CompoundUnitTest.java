package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit;

import org.junit.jupiter.api.Test;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import java.util.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.CompoundUnit.FORMAT_OF_UNIT_VALUE;

class CompoundUnitTest {
	private static final String UNIT_ID = "1";
	private static final List<Unit> DIRECT_UNITS = Collections.emptyList();
	private static final List<Unit> INVERSE_UNITS = Collections.emptyList();
	private static final double DIRECT_RATIO_VALUE = 4.0;
	private static final double INVERSE_RATIO_VALUE = 2.0;
	private static final String ANOTHER_UNIT_ID = "2";
	private static final String DIRECT_UNIT_ID = "м";
	private static final String INVERSE_UNIT_ID = "c";
	private static final String FORMATTED_UNIT_VALUE = String.format(FORMAT_OF_UNIT_VALUE, DIRECT_UNIT_ID, INVERSE_UNIT_ID);

	@Test
	void returnsConversionRatioEqualsToOneForSameUnit() throws Exception {
		Unit toUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), DIRECT_UNITS, INVERSE_UNITS);
		var compoundUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), DIRECT_UNITS, INVERSE_UNITS);

		final double expectedConversionRatio = 1.0;


		double conversionRatio = compoundUnit.getConversionRatioTo(toUnit);


		assertThat(conversionRatio, equalTo(expectedConversionRatio));
	}

	@Test
	void returnsConversionRatioForSpecifiedUnit() throws Exception {
		Unit directAtomicUnit = mock(Unit.class);
		Unit toDirectAtomicUnit = mock(Unit.class);
		given(directAtomicUnit.getConversionRatioTo(toDirectAtomicUnit)).willReturn(DIRECT_RATIO_VALUE);

		Unit inverseAtomicUnit = mock(Unit.class);
		Unit toInverseAtomicUnit = mock(Unit.class);
		given(inverseAtomicUnit.getConversionRatioTo(toInverseAtomicUnit)).willReturn(INVERSE_RATIO_VALUE);

		Unit toUnit = new CompoundUnit(ANOTHER_UNIT_ID, mock(UnitType.class), List.of(toDirectAtomicUnit), List.of(toInverseAtomicUnit));
		var compoundUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), List.of(directAtomicUnit), List.of(inverseAtomicUnit));

		final double expectedConversionRatio = 2.0;


		double conversionRatio = compoundUnit.getConversionRatioTo(toUnit);


		assertThat(conversionRatio, equalTo(expectedConversionRatio));
	}

	@Test
	void throwExceptionWhenGetConversionRatioForOtherClassUnit() {
		Unit toUnit = mock(Unit.class);
		var compoundUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), DIRECT_UNITS, INVERSE_UNITS);


		assertThrows(UnitConversionException.class, () -> compoundUnit.getConversionRatioTo(toUnit));
	}

	@Test
	void throwExceptionWhenGetConversionRatioForSameClassUnitWithDifferentSizeOfDirectUnits() {
		Unit toUnit = new CompoundUnit(ANOTHER_UNIT_ID, mock(UnitType.class), List.of(mock(Unit.class), mock(Unit.class)), List.of(mock(Unit.class)));
		var compoundUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), List.of(mock(Unit.class)), List.of(mock(Unit.class)));


		assertThrows(UnitConversionException.class, () -> compoundUnit.getConversionRatioTo(toUnit));
	}

	@Test
	void throwExceptionWhenGetConversionRatioForSameClassUnitWithDifferentSizeOfInverseUnits() {
		Unit toUnit = new CompoundUnit(ANOTHER_UNIT_ID, mock(UnitType.class), List.of(mock(Unit.class)), List.of(mock(Unit.class), mock(Unit.class)));
		var compoundUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), List.of(mock(Unit.class)), List.of(mock(Unit.class)));


		assertThrows(UnitConversionException.class, () -> compoundUnit.getConversionRatioTo(toUnit));
	}

	@Test
	void returnsFormattedUnitValue() {
		Unit directAtomicUnit = mock(Unit.class);
		given(directAtomicUnit.formattedValue()).willReturn(DIRECT_UNIT_ID);

		Unit inverseAtomicUnit = mock(Unit.class);
		given(inverseAtomicUnit.formattedValue()).willReturn(INVERSE_UNIT_ID);

		var compoundUnit = new CompoundUnit(UNIT_ID, mock(UnitType.class), List.of(directAtomicUnit), List.of(inverseAtomicUnit));


		var formattedUnitValue = compoundUnit.formattedValue();


		assertThat(formattedUnitValue, equalTo(FORMATTED_UNIT_VALUE));
	}
}