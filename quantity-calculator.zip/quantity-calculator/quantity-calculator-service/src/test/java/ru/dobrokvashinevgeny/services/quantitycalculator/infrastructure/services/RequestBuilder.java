/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import org.jboss.resteasy.mock.MockHttpRequest;

import javax.ws.rs.core.MediaType;
import java.net.URISyntaxException;
import java.nio.charset.*;

public class RequestBuilder {
	private static final Charset CONTENT_CHARSET = StandardCharsets.UTF_8;

	private MockHttpRequest result;

	/**
	 * Установить GET запрос для ресурса
	 *
	 * @param uri URI ресурса
	 * @return Builder
	 * @throws URISyntaxException если ошибка в синтаксисе uri
	 */
	public RequestBuilder getRequestTo(String uri) throws URISyntaxException {
		result = MockHttpRequest.get(uri);
		return this;
	}

	/**
	 * Установить POST запрос для ресурса
	 *
	 * @param uri URI ресурса
	 * @return Builder
	 * @throws URISyntaxException если ошибка в синтаксисе uri
	 */
	public RequestBuilder postRequestTo(String uri) throws URISyntaxException {
		result = MockHttpRequest.post(uri);
		return this;
	}

	/**
	 * Установить PUT запрос для ресурса
	 *
	 * @param uri URI ресурса
	 * @return Builder
	 * @throws URISyntaxException если ошибка в синтаксисе uri
	 */
	public RequestBuilder putRequestTo(String uri) throws URISyntaxException {
		result = MockHttpRequest.put(uri);
		return this;
	}

	/**
	 * Установить DELETE запрос для ресурса
	 *
	 * @param uri URI ресурса
	 * @return Builder
	 * @throws URISyntaxException если ошибка в синтаксисе uri
	 */
	public RequestBuilder deleteRequestTo(String uri) throws URISyntaxException {
		result = MockHttpRequest.delete(uri);
		return this;
	}

	/**
	 * Установить принимаемый MediaType
	 *
	 * @param acceptedMediaType принимаемый MediaType
	 * @return Builder
	 */
	public RequestBuilder acceptMediaType(String acceptedMediaType) {
		result.accept(acceptedMediaType);
		return this;
	}

	/**
	 * Установить принимаемый MediaType
	 *
	 * @param acceptedMediaType принимаемый MediaType
	 * @return Builder
	 */
	public RequestBuilder acceptMediaType(MediaType acceptedMediaType) {
		result.accept(acceptedMediaType);
		return this;
	}

	/**
	 * Установить тип контента
	 *
	 * @param contentType тип контента
	 * @return Builder
	 */
	public RequestBuilder contentType(MediaType contentType) {
		result.contentType(contentType);
		return this;
	}

	/**
	 * Установить содержимое контента
	 *
	 * @param content содержимое контента
	 * @return Builder
	 */
	public RequestBuilder content(String content) {
		result.content(content.getBytes(CONTENT_CHARSET));
		return this;
	}

	/**
	 * Построить MockHttpRequest
	 *
	 * @return построенный MockHttpRequest
	 */
	public MockHttpRequest build() {
		return result;
	}
}