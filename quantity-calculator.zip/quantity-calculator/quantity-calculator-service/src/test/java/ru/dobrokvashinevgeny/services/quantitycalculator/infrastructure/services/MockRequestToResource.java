/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import org.jboss.resteasy.core.*;
import org.jboss.resteasy.mock.*;
import org.jboss.resteasy.spi.Dispatcher;

public class MockRequestToResource {
	private final Dispatcher dispatcher;

	public MockRequestToResource(Dispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}

	public MockHttpResponse getAsyncResponseFor(MockHttpRequest request) {
		MockHttpResponse response = new MockHttpResponse();

		SynchronousExecutionContext synchronousExecutionContext =
			new SynchronousExecutionContext((SynchronousDispatcher) dispatcher, request, response);
		request.setAsynchronousContext(synchronousExecutionContext);

		return sendHttpRequest(request, response);
	}

	private MockHttpResponse sendHttpRequest(MockHttpRequest request, MockHttpResponse response) {
		dispatcher.invoke(request, response);
		return response;
	}
}