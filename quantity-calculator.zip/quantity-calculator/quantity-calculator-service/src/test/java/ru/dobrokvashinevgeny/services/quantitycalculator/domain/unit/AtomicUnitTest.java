package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

class AtomicUnitTest {
	private static final String UNIT_ID = "м";
	private static final double RATIO_VALUE = 2.0;
	private static final double INVERSE_RATIO_VALUE = 1 / RATIO_VALUE;
	private static final String ANOTHER_UNIT_ID = "км";

	private UnitConversionRatios unitConversionRatios;

	@BeforeEach
	void setUp() {
		unitConversionRatios = mock(UnitConversionRatios.class);
	}

	@Test
	void returnsConversionRatioEqualsToOneForSameUnit() throws Exception {
		final UnitType unitType = mock(UnitType.class);
		Unit toUnit = new AtomicUnit(UNIT_ID, unitType, unitConversionRatios);
		var atomicUnit = new AtomicUnit(UNIT_ID, unitType, unitConversionRatios);

		final double expectedConversionRatio = 1.0;


		double conversionRatio = atomicUnit.getConversionRatioTo(toUnit);


		assertThat(conversionRatio, equalTo(expectedConversionRatio));
	}

	@Test
	void returnsConversionRatioForSpecifiedUnit() throws Exception {
		Unit toUnit = new AtomicUnit(ANOTHER_UNIT_ID, mock(UnitType.class), unitConversionRatios);
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);
		given(unitConversionRatios.conversionRatioOf(atomicUnit, toUnit))
			.willReturn(new UnitConversionRatio(atomicUnit, toUnit, RATIO_VALUE));


		double conversionRatio = atomicUnit.getConversionRatioTo(toUnit);


		assertThat(conversionRatio, equalTo(RATIO_VALUE));
	}

	@Test
	void newInstanceDirectUnitListContainsOneElementTheSelf() {
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);


		assertThat(atomicUnit.directUnitList(), hasSize(1));
		assertThat(atomicUnit.directUnitList(), hasItem(atomicUnit));
	}

	@Test
	void newInstanceReturnsEmptyInverseUnitList() {
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);


		assertThat(atomicUnit.inverseUnitList(), is(empty()));
	}

	@Test
	void throwExceptionWhenGetConversionRatioForOtherClassUnit() {
		Unit toUnit = mock(Unit.class);
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);


		assertThrows(UnitConversionException.class, () -> atomicUnit.getConversionRatioTo(toUnit));
	}

	@Test
	void returnsConversionRatioForSpecifiedUnitWhenExistsOnlyInverseRatio() throws Exception {
		Unit toUnit = new AtomicUnit(ANOTHER_UNIT_ID, mock(UnitType.class), unitConversionRatios);
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);
		given(unitConversionRatios.conversionRatioOf(toUnit, atomicUnit))
			.willReturn(new UnitConversionRatio(atomicUnit, toUnit, RATIO_VALUE));
		given(unitConversionRatios.conversionRatioOf(atomicUnit, toUnit))
			.willThrow(ConversionRatioNotFoundException.class);


		double conversionRatio = atomicUnit.getConversionRatioTo(toUnit);


		assertThat(conversionRatio, equalTo(INVERSE_RATIO_VALUE));
	}

	@Test
	void throwExceptionWhenGetConversionRatioNotFound() throws Exception {
		Unit toUnit = new AtomicUnit(ANOTHER_UNIT_ID, mock(UnitType.class), unitConversionRatios);
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);
		given(unitConversionRatios.conversionRatioOf(toUnit, atomicUnit))
			.willThrow(ConversionRatioNotFoundException.class);
		given(unitConversionRatios.conversionRatioOf(atomicUnit, toUnit))
			.willThrow(ConversionRatioNotFoundException.class);


		assertThrows(UnitConversionException.class, () -> atomicUnit.getConversionRatioTo(toUnit));
	}

	@Test
	void returnsFormattedUnitValue() {
		var atomicUnit = new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios);


		var formattedUnitValue = atomicUnit.formattedValue();


		assertThat(formattedUnitValue, equalTo(UNIT_ID));
	}
}