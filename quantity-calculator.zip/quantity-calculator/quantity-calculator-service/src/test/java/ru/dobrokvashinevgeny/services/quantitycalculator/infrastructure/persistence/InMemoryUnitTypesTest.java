package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.*;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class InMemoryUnitTypesTest {
	private static final int ZERO_SIZE = 0;
	private static final int ONE_UNIT_TYPE = 1;
	private static final String UNIT_TYPE_ID = "speed";
	private static final String UNIT_TYPE_NAME = "Скорость";

	@Test
	void hasZeroSizeOfNewInstance() {
		var unitTypes = new InMemoryUnitTypes();


		assertThat(unitTypes.size(), equalTo(ZERO_SIZE));
	}

	@Test
	void increaseSizeByOneAfterAddNewUnitType() {
		var unitTypes = new InMemoryUnitTypes();


		unitTypes.add(new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME));


		assertThat(unitTypes.size(), equalTo(ONE_UNIT_TYPE));
	}

	@Test
	void returnsAddedUnitTypeById() throws Exception {
		var unitTypes = new InMemoryUnitTypes();

		final var unitType = new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME);
		unitTypes.add(unitType);


		assertThat(unitTypes.unitTypeOfId(UNIT_TYPE_ID), equalTo(unitType));
	}

	@Test
	void throwExceptionWhenUnitTypeNotFound() {
		var unitTypes = new InMemoryUnitTypes();


		assertThrows(UnitTypeNotFoundException.class, () -> unitTypes.unitTypeOfId(UNIT_TYPE_ID));
	}

	@Test
	void returnsUnitTypeList() {
		var unitTypes = new InMemoryUnitTypes();

		final var unitType = new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME);
		unitTypes.add(unitType);

		var expectedUnitTypeList = List.of(unitType);


		var unitTypeList = unitTypes.unitTypeList();


		assertThat(unitTypeList, equalTo(expectedUnitTypeList));
	}
}