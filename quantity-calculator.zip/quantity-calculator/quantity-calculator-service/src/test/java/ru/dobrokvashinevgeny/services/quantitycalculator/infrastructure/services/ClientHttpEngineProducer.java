/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.*;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.*;
import org.apache.http.impl.client.*;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.jboss.resteasy.client.jaxrs.ClientHttpEngine;
import org.jboss.resteasy.client.jaxrs.engines.ApacheHttpClient43Engine;

import javax.net.ssl.*;
import java.io.*;
import java.net.URI;
import java.security.*;
import java.security.cert.CertificateException;

public class ClientHttpEngineProducer {
	private static final String HTTPS_PROTOCOL = "https";
	private static final String HTTPS_SOCKET_FACTORY_ID = "https";
	private static final String SSL_CONTEXT_TYPE = "TLSv1";
	private static final String KEY_STORE_TYPE = "JKS";

	private final FileService fileService;
	private final URI resourceUri;
	private final int connectTimeout;
	private final String httpsResourceKeyStoreLocation;
	private final char[] httpsResourceKeyStorePassword;

	public ClientHttpEngineProducer(FileService fileService, URI resourceUri, int connectTimeout,
									String httpsResourceKeyStoreLocation,
									char[] httpsResourceKeyStorePassword) {
		this.fileService = fileService;
		this.resourceUri = resourceUri;
		this.connectTimeout = connectTimeout;
		this.httpsResourceKeyStoreLocation = httpsResourceKeyStoreLocation;
		this.httpsResourceKeyStorePassword = httpsResourceKeyStorePassword;
	}

	public ClientHttpEngine createClientHttpEngineBy() throws CertificateException,
		NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException, FileServiceException {
		boolean useSsl = resourceUri.getScheme().equalsIgnoreCase(HTTPS_PROTOCOL);

		RequestConfig restClientConfigWithSetTimeouts = RequestConfig.custom()
			.setConnectTimeout(connectTimeout)
			.setConnectionRequestTimeout(connectTimeout)
			.setSocketTimeout(connectTimeout)
			.build();

		CloseableHttpClient httpClient =  HttpClientBuilder.create()
			.setDefaultRequestConfig(restClientConfigWithSetTimeouts)
			.setConnectionManager(getConnectionManager(useSsl))
			.build();

		return new ApacheHttpClient43Engine(httpClient);
	}

	private PoolingHttpClientConnectionManager getConnectionManager(boolean useSsl) throws CertificateException,
		NoSuchAlgorithmException, KeyStoreException, KeyManagementException, FileServiceException, IOException {
		PoolingHttpClientConnectionManager poolingConnectionManager;

		if (useSsl) {
			poolingConnectionManager = new PoolingHttpClientConnectionManager(createSocketFactoryRegistry());
		} else {
			poolingConnectionManager = new PoolingHttpClientConnectionManager();
		}

		return poolingConnectionManager;
	}

	private Registry<ConnectionSocketFactory> createSocketFactoryRegistry() throws CertificateException,
		NoSuchAlgorithmException, KeyStoreException, IOException, KeyManagementException, FileServiceException {
		SSLConnectionSocketFactory sslConnectionSocketFactory =
			new SSLConnectionSocketFactory(
				getSslContext(),
				new DefaultHostnameVerifier()
			);

		return RegistryBuilder.<ConnectionSocketFactory>create()
			.register(HTTPS_SOCKET_FACTORY_ID, sslConnectionSocketFactory)
			.build();
	}

	private SSLContext getSslContext() throws CertificateException, NoSuchAlgorithmException, KeyStoreException,
		FileServiceException, IOException, KeyManagementException {
		TrustManagerFactory trustManagerFactory = getTrustManagerFactory();
		SSLContext sslContext = SSLContext.getInstance(SSL_CONTEXT_TYPE);
		sslContext.init(null, trustManagerFactory.getTrustManagers(), null);

		return sslContext;
	}

	private TrustManagerFactory getTrustManagerFactory() throws NoSuchAlgorithmException, KeyStoreException,
		FileServiceException, IOException, CertificateException {
		TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
		trustManagerFactory.init(getKeyStore());

		return trustManagerFactory;
	}

	private KeyStore getKeyStore()
		throws KeyStoreException, NoSuchAlgorithmException, FileServiceException, IOException, CertificateException {
		KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);

		try (InputStream keyStoreStream = fileService.getFileInputStreamByName(httpsResourceKeyStoreLocation)) {
			keyStore.load(keyStoreStream, httpsResourceKeyStorePassword);
		}

		return keyStore;
	}
}