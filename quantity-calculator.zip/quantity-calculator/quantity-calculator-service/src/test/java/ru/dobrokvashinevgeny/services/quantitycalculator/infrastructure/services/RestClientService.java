/*
 * Copyright (c) 2018 Tander, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import org.slf4j.*;

import javax.ws.rs.ProcessingException;
import javax.ws.rs.client.*;
import javax.ws.rs.core.*;
import java.net.URI;

public class RestClientService {
	public static final Logger LOG = LoggerFactory.getLogger(RestClientService.class);
	private static final String EMPTY_BODY = "";
	private static final String JSON_WITH_UTF_MEDIA_TYPE = MediaType.APPLICATION_JSON_TYPE + ";" +
		MediaType.CHARSET_PARAMETER + "=utf-8;";

	private final Client restClient;

	public RestClientService(Client restClient) {
		this.restClient = restClient;
	}

	public <RequestEntity, ResponseEntity> ResponseEntity getJsonPostRequestResultFor(
		URI resourceUri , RequestEntity requestJsonEntity, Class<ResponseEntity> responseJsonEntityClass)
		throws RestClientServiceException {
		LOG.info(resourceUri.toString());

		WebTarget target = restClient.target(resourceUri);
		try (Response response =
				 target.request(JSON_WITH_UTF_MEDIA_TYPE)
					 .post(Entity.entity(requestJsonEntity, JSON_WITH_UTF_MEDIA_TYPE))) {
			LOG.info(response.toString());
			return response.readEntity(responseJsonEntityClass);
		} catch (ProcessingException e) {
			throw new RestClientServiceException(e);
		}
	}

	Client getRestClient() {
		return restClient;
	}

	public <ResponseEntity> ResponseEntity getJsonPostRequestResultFor(
		URI resourceUri, Class<ResponseEntity> responseJsonEntityClass) throws RestClientServiceException {
		WebTarget target = restClient.target(resourceUri);
		try (Response response =
				 target.request(JSON_WITH_UTF_MEDIA_TYPE)
					 .post(Entity.text(EMPTY_BODY))) {
			return response.readEntity(responseJsonEntityClass);
		} catch (ProcessingException e) {
			throw new RestClientServiceException(e);
		}
	}

	public int checkGetHealthRequestFor(URI resourceUri) throws RestClientServiceException {
		WebTarget target = restClient.target(resourceUri);

		try (Response response =
				 target.request(JSON_WITH_UTF_MEDIA_TYPE)
					 .post(Entity.text(EMPTY_BODY))) {
			return response.getStatus();
		} catch (ProcessingException e) {
			throw new RestClientServiceException(e);
		}
	}
}