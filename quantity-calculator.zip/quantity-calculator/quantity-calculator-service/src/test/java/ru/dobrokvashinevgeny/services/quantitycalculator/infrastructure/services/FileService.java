/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import java.io.*;
import java.nio.file.OpenOption;

public interface FileService {
	InputStream getFileInputStreamByName(String fileName, OpenOption... openOptions) throws FileServiceException;

	OutputStream getFileOutputStreamByName(String fileName) throws FileServiceException;

	void removeFileByName(String fileName) throws FileServiceException;
}