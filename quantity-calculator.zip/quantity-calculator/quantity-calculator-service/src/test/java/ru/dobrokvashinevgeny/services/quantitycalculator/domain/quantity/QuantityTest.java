package ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity.QuantityDesc;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

class QuantityTest {
	private static final double AMOUNT = 5;
	private static final double CONVERSION_RATIO = 0.001;
	private static final double CONVERTED_AMOUNT = AMOUNT * CONVERSION_RATIO;
	private static final String UNIT_ID = "м";
	private Unit unit;
	private Unit toUnit;

	@BeforeEach
	void setUp() {
		unit = mock(Unit.class);
		toUnit = mock(Unit.class);
	}

	@Test
	void returnsNewQuantityEqualsToCurrentWhenConvertingToSameUnit() throws Exception {
		Quantity quantityToConvert = new Quantity(AMOUNT, unit);

		Quantity expectedQuantity = new Quantity(AMOUNT, unit);


		Quantity convertedQuantity = quantityToConvert.convertTo(unit);


		assertThat(convertedQuantity, equalTo(expectedQuantity));
	}

	@Test
	void returnsConvertedQuantityToSpecifiedUnit() throws Exception {
		given(unit.getConversionRatioTo(toUnit)).willReturn(CONVERSION_RATIO);

		Quantity quantityToConvert = new Quantity(AMOUNT, unit);

		Quantity expectedQuantity = new Quantity(CONVERTED_AMOUNT, toUnit);


		Quantity convertedQuantity = quantityToConvert.convertTo(toUnit);


		assertThat(convertedQuantity, equalTo(expectedQuantity));
	}

	@Test
	void correctlyFillsSpecifiedFillableQuantityDesc() {
		given(unit.unitId()).willReturn(UNIT_ID);
		Quantity quantity = new Quantity(AMOUNT, unit);

		FillableQuantityDesc fillableQuantityDesc = new QuantityDesc();

		FillableQuantityDesc expectedFillableQuantityDesc = new QuantityDesc(AMOUNT, UNIT_ID);


		quantity.fillQuantityDesc(fillableQuantityDesc);


		assertThat(fillableQuantityDesc, equalTo(expectedFillableQuantityDesc));
	}

	@Test
	void throwExceptionWhenGetUnitConversionRatioFailed() throws Exception {
		Quantity quantity = new Quantity(AMOUNT, unit);

		given(unit.getConversionRatioTo(toUnit)).willThrow(UnitConversionException.class);


		assertThrows(QuantityConvertException.class, () -> quantity.convertTo(toUnit));
	}
}