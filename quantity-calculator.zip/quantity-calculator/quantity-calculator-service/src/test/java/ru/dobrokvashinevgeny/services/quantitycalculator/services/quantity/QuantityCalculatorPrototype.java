/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity;

public class QuantityCalculatorPrototype {
	public static void main(String[] args) {
		/*UnitConversionRatios unitConversionRatios = new UnitConversionRatios();

		UnitTypes unitTypes = new UnitTypes();
		unitTypes.add(new UnitType("distance", "Расстояние"));
		unitTypes.add(new UnitType("mass", "Масса"));
		unitTypes.add(new UnitType("time", "Время"));
		unitTypes.add(new UnitType("speed", "Скорость"));
		unitTypes.add(new UnitType("momentum", "Момент"));

		Units units = new Units();
		units.add(new AtomicUnit("км", unitTypes.unitTypeById("distance"), unitConversionRatios));
		units.add(new AtomicUnit("м", unitTypes.unitTypeById("distance"), unitConversionRatios));
		units.add(new AtomicUnit("с", unitTypes.unitTypeById("time"), unitConversionRatios));
		units.add(new AtomicUnit("кг", unitTypes.unitTypeById("mass"), unitConversionRatios));
		units.add(
			new CompoundUnit(
			"1",
			unitTypes.unitTypeById("momentum"),
			List.of(units.unitOfId("кг"), units.unitOfId("м")),
			List.of(units.unitOfId("с")))
		);
		units.add(
			new CompoundUnit(
				"2",
				unitTypes.unitTypeById("speed"),
				List.of(units.unitOfId("м")),
				List.of(units.unitOfId("с")))
		);
		units.add(
			new CompoundUnit(
				"3",
				unitTypes.unitTypeById("speed"),
				List.of(units.unitOfId("км")),
				List.of(units.unitOfId("с")))
		);

		unitConversionRatios.add(
			new UnitConversionRatio(
				units.unitOfId("км"), units.unitOfId("м"), 1000
			)
		);

		System.out.println(units.unitOfId("3").formattedValue());

		Quantity distanceQuantity = new Quantity(2, units.unitOfId("м"));
		System.out.println(distanceQuantity.convertTo(units.unitOfId("км")).formattedValue());

		Quantity speedQuantity = new Quantity(10, units.unitOfId("3"));
		System.out.println("speedQuantity: " + speedQuantity.formattedValue());

		Quantity convertedSpeedQuantity = speedQuantity.convertTo(units.unitOfId("2"));
		System.out.println("convertedSpeedQuantity: " + convertedSpeedQuantity.formattedValue());


		Quantity sumOfSpeedsQuantities = speedQuantity.add(convertedSpeedQuantity);
		System.out.println("sumOfSpeedsQuantities: " + sumOfSpeedsQuantities.formattedValue());*/
	}
}

/*class UnitType {
	private String unitTypeId;
	private String unitTypeName;

	public UnitType(String unitTypeId, String unitTypeName) {
		this.unitTypeId = unitTypeId;
		this.unitTypeName = unitTypeName;
	}

	public String getUnitTypeId() {
		return unitTypeId;
	}

	public String getUnitTypeName() {
		return unitTypeName;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		UnitType unitType = (UnitType) o;
		return getUnitTypeId().equals(unitType.getUnitTypeId()) &&
			getUnitTypeName().equals(unitType.getUnitTypeName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getUnitTypeId(), getUnitTypeName());
	}

	@Override
	public String toString() {
		return "UnitType{" +
			"unitTypeId='" + unitTypeId + '\'' +
			", unitTypeName='" + unitTypeName + '\'' +
			'}';
	}
}

class UnitTypes {
	private List<UnitType> unitTypeStore = new ArrayList<>();

	public void add(UnitType unitType) {
		unitTypeStore.add(unitType);
	}

	public UnitType unitTypeById(String unitTypeId) {
		return unitTypeStore
			.stream()
			.filter(unitType -> unitType.getUnitTypeId().equals(unitTypeId))
			.findFirst().orElseThrow();
	}

	public List<String> unitTypeNames() {
		return unitTypeStore
			.stream()
			.map(UnitType::getUnitTypeName)
			.collect(toList());
	}
}

abstract class Unit {
	private final String unitId;
	private final UnitType unitType;

	public Unit(String unitId, UnitType unitType) {
		this.unitId = unitId;
		this.unitType = unitType;
	}

	public String unitId() {
		return this.unitId;
	}

	boolean isTypeOf(UnitType unitType) {
		return this.unitType.equals(unitType);
	}

	abstract String formattedValue();

	abstract double getConversionRatioTo(Unit toUnit);

	abstract List<Unit> directUnitList();

	abstract List<Unit> inverseUnitList();

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Unit unit = (Unit) o;
		return unitId.equals(unit.unitId) &&
			unitType.equals(unit.unitType);
	}

	@Override
	public int hashCode() {
		return Objects.hash(unitId, unitType);
	}
}

class Units {
	private List<Unit> unitStore = new ArrayList<>();

	public void add(Unit unit) {
		unitStore.add(unit);
	}

	public Unit unitOfId(String unitId) {
		return unitStore
			.stream()
			.filter(unit -> unit.unitId().equalsIgnoreCase(unitId))
			.findFirst().orElseThrow();
	}

	public List<String> unitFormattedValuesOfType(UnitType unitType) {
		return unitStore
			.stream()
			.filter(unit -> unit.isTypeOf(unitType))
			.map(Unit::formattedValue)
			.collect(toList());
	}
}

class AtomicUnit extends Unit {
	private final UnitConversionRatios unitConversionRatios;

	public AtomicUnit(String unitId, UnitType unitType, UnitConversionRatios unitConversionRatios) {
		super(unitId, unitType);
		this.unitConversionRatios = unitConversionRatios;
	}

	@Override
	public String formattedValue() {
		return unitId();
	}

	@Override
	public double getConversionRatioTo(Unit toUnit) {
		if (this.equals(toUnit)) {
			return 1;
		}

		if (getClass() != toUnit.getClass()) {
			throw new RuntimeException("Can't convert to");
		}

		UnitConversionRatio conversionRatio;
		double ratioValue;
		try {
			conversionRatio = unitConversionRatios.conversionRatioOf(this, toUnit);

			ratioValue = conversionRatio.getRatioValue();
		} catch (Exception e) {
			conversionRatio = unitConversionRatios.conversionRatioOf(toUnit, this);
			ratioValue = 1.0 / conversionRatio.getRatioValue();
		}

		return ratioValue;
	}

	@Override
	public List<Unit> directUnitList() {
		return List.of(this);
	}

	@Override
	public List<Unit> inverseUnitList() {
		return Collections.emptyList();
	}
}

class UnitConversionRatios {
	private List<UnitConversionRatio> unitConversionRatioStore = new ArrayList<>();

	public void add(UnitConversionRatio unitConversionRatio) {
		unitConversionRatioStore.add(unitConversionRatio);
	}

	public UnitConversionRatio conversionRatioOf(Unit fromUnit, Unit toUnit) {
		return
			unitConversionRatioStore
			.stream()
			.filter(unitConversionRatio -> unitConversionRatio.getFromUnit().equals(fromUnit)
												 && unitConversionRatio.getToUnit().equals(toUnit))
			.findFirst().orElseThrow();
	}
}

class UnitConversionRatio {
	private final Unit fromUnit;
	private final Unit toUnit;
	private final int ratioValue;

	public UnitConversionRatio(Unit fromUnit, Unit toUnit, int ratioValue) {
		this.fromUnit = fromUnit;
		this.toUnit = toUnit;
		this.ratioValue = ratioValue;
	}

	public Unit getFromUnit() {
		return fromUnit;
	}

	public Unit getToUnit() {
		return toUnit;
	}

	public int getRatioValue() {
		return ratioValue;
	}
}

class CompoundUnit extends Unit {
	private final List<Unit> directUnits;
	private final List<Unit> inverseUnits;

	public CompoundUnit(String unitId, UnitType unitType, List<Unit> directUnits, List<Unit> inverseUnits) {
		super(unitId, unitType);
		this.directUnits = directUnits;
		this.inverseUnits = inverseUnits;
	}

	public boolean containsDirectUnits(List<AtomicUnit> directUnits) {
		return
			this.directUnits.size() == directUnits.size()
			&& this.directUnits.containsAll(directUnits);
	}

	public boolean containsInverseUnits(List<AtomicUnit> inverseUnits) {
		return
			this.inverseUnits.size() == inverseUnits.size()
				&& this.inverseUnits.containsAll(inverseUnits);
	}

	@Override
	public String formattedValue() {
		return
			formatUnitList(directUnits) + "/" + formatUnitList(inverseUnits);
	}

	@Override
	public double getConversionRatioTo(Unit toUnit) {
		if (this.equals(toUnit)) {
			return 1;
		}

		if (getClass() != toUnit.getClass()
			&& (directUnits.size() != toUnit.directUnitList().size()
			|| inverseUnits.size() != toUnit.inverseUnitList().size())) {
			throw new RuntimeException("Can't convert to");
		}

		int directUnitIndex = 0;
		double directUnitsRatio = 1.0;
		for (Unit directUnit : directUnits) {
			directUnitsRatio *= directUnit.getConversionRatioTo(toUnit.directUnitList().get(directUnitIndex++));
		}

		int inverseUnitIndex = 0;
		double inverseUnitsRatio = 1.0;
		for (Unit inverseUnit : inverseUnits) {
			inverseUnitsRatio *= inverseUnit.getConversionRatioTo(toUnit.inverseUnitList().get(inverseUnitIndex++));
		}

		return directUnitsRatio / inverseUnitsRatio;
	}

	@Override
	public List<Unit> directUnitList() {
		return new ArrayList<>(directUnits);
	}

	@Override
	public List<Unit> inverseUnitList() {
		return new ArrayList<>(inverseUnits);
	}

	private String formatUnitList(List<Unit> unitList) {
		return
			unitList
			.stream()
			.map(Unit::formattedValue)
			.collect(joining("*"));
	}
}

class Quantity {
	private final double amount;
	private final Unit unit;

	public Quantity(double amount, Unit unit) {
		this.amount = amount;
		this.unit = unit;
	}

	public Quantity convertTo(Unit toUnit) {
		if (unit.equals(toUnit)) {
			return new Quantity(amount, unit);
		}

		return new Quantity(amount * unit.getConversionRatioTo(toUnit), toUnit);
	}

	public Quantity add(Quantity anotherQuantity) {
		Quantity convertedAnotherQuantity = anotherQuantity.convertTo(unit);

		return new Quantity(amount + convertedAnotherQuantity.amount, unit);
	}

	public String formattedValue() {
		return amount + " " + unit.formattedValue();
	}
}*/