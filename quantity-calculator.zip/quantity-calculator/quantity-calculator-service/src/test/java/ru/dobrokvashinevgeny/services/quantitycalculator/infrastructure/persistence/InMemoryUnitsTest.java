package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.UnitConversionRatios;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

class InMemoryUnitsTest {
	private static final int ZERO_SIZE = 0;
	private static final int ONE_UNIT = 1;
	private static final String UNIT_ID = "м";
	private static final String UNIT_TYPE_ID = "speed";
	private static final String UNIT_TYPE_NAME = "Скорость";

	private UnitConversionRatios unitConversionRatios;
	private UnitType mockedUnitType;

	@BeforeEach
	void setUp() {
		unitConversionRatios = mock(UnitConversionRatios.class);
		mockedUnitType = mock(UnitType.class);
	}

	@Test
	void hasZeroSizeOfNewInstance() {
		var units = new InMemoryUnits();


		assertThat(units.size(), equalTo(ZERO_SIZE));
	}

	@Test
	void increaseSizeByOneAfterAddNewUnit() {
		var units = new InMemoryUnits();


		units.add(new AtomicUnit(UNIT_ID, mockedUnitType, unitConversionRatios));


		assertThat(units.size(), equalTo(ONE_UNIT));
	}

	@Test
	void returnsAddedUnitById() throws Exception {
		var units = new InMemoryUnits();

		final var unit = new AtomicUnit(UNIT_ID, mockedUnitType, unitConversionRatios);
		units.add(unit);


		assertThat(units.unitOfId(UNIT_ID), equalTo(unit));
	}

	@Test
	void throwExceptionWhenUnitNotFound() {
		var units = new InMemoryUnits();


		assertThrows(UnitNotFoundException.class, () -> units.unitOfId(UNIT_ID));
	}

	@Test
	void returnsUnitsOfType() {
		final UnitType unitType = new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME);
		final AtomicUnit unit = new AtomicUnit(UNIT_ID, unitType, unitConversionRatios);

		var units = new InMemoryUnits();
		units.add(unit);

		List<Unit> expectedUnitsOfType = List.of(unit);


		var unitsOfType = units.unitsOfType(unitType);


		assertThat(unitsOfType, equalTo(expectedUnitsOfType));
	}
}