package ru.dobrokvashinevgeny.services.quantitycalculator.services.unit;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.UnitConversionRatios;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.*;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

class UnitServiceTest {
	private static final String UNIT_TYPE_ID = "speed";
	private static final String UNIT_TYPE_NAME = "Скорость";
	private static final String UNIT_FORMATTED_VALUE_ONE = "км/с";
	private static final String UNIT_ID = "км";
	private static final String ANOTHER_UNIT_ID = "с";
	private static final String NOT_EXISTS_UNIT_TYPE_ID = "123";

	private UnitTypes unitTypes;
	private Units units;
	private UnitConversionRatios unitConversionRatios;

	@BeforeEach
	void setUp() {
		unitTypes = mock(UnitTypes.class);
		units = mock(Units.class);
		unitConversionRatios = mock(UnitConversionRatios.class);
	}

	@Test
	void returnListOfExistingUnitTypes() {
		given(unitTypes.unitTypeList()).willReturn(List.of(new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME)));
		var unitService = new UnitService(unitTypes, units);

		var expectedListOfExistingUnitTypes = new UnitTypeNamesDesc(List.of(UNIT_TYPE_NAME));


		var listOfExistingUnitTypes = unitService.getUnitTypeNames();


		assertThat(listOfExistingUnitTypes, equalTo(expectedListOfExistingUnitTypes));
	}

	@Test
	void returnListOfUnitFormattedValuesOfTypeId() throws Exception {
		given(unitTypes.unitTypeOfId(UNIT_TYPE_ID)).willReturn(new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME));
		given(units.unitsOfType(new UnitType(UNIT_TYPE_ID, UNIT_TYPE_NAME)))
			.willReturn(
				List.of(
					new CompoundUnit(
						"1",
						mock(UnitType.class),
						List.of(new AtomicUnit(UNIT_ID, mock(UnitType.class), unitConversionRatios)),
						List.of(new AtomicUnit(ANOTHER_UNIT_ID, mock(UnitType.class), unitConversionRatios))
					)
				)
			);
		var unitService = new UnitService(unitTypes, units);

		var expectedListOfUnitFormattedValues
			= new UnitFormattedValuesDesc(List.of(UNIT_FORMATTED_VALUE_ONE));


		var listOfUnitFormattedValues = unitService.getUnitFormattedValuesOfUnitTypeId(UNIT_TYPE_ID);


		assertThat(listOfUnitFormattedValues, equalTo(expectedListOfUnitFormattedValues));
	}

	@Test
	void throwExceptionWhenGetListOfUnitFormattedValuesOfTypeIdThenUnitTypeNotFound() throws Exception {
		given(unitTypes.unitTypeOfId(NOT_EXISTS_UNIT_TYPE_ID)).willThrow(UnitTypeNotFoundException.class);
		var unitService = new UnitService(unitTypes, units);


		assertThrows(UnitServiceException.class, () -> unitService.getUnitFormattedValuesOfUnitTypeId(NOT_EXISTS_UNIT_TYPE_ID));
	}
}