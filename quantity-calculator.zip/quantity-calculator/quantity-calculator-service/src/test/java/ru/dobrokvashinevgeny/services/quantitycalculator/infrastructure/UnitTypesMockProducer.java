/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitTypes;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

import static org.mockito.Mockito.mock;

@ApplicationScoped
public class UnitTypesMockProducer {
	private UnitTypes units = mock(UnitTypes.class);

	@Produces
	UnitTypes units() {
		return units;
	}
}