/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services;

import org.jboss.resteasy.mock.MockHttpResponse;

import javax.ws.rs.core.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ComparableMockHttpResponse {
	private final int status;
	private final byte[] content;
	private final MultivaluedMap<String, Object> outputHeaders;
	private final List<NewCookie> newCookies;
	private final String errorMessage;
	private final boolean sentError;
	private boolean compareContent;

	public ComparableMockHttpResponse(MockHttpResponse mockHttpResponse) {
		status = mockHttpResponse.getStatus();
		content = mockHttpResponse.getOutput();
		outputHeaders = mockHttpResponse.getOutputHeaders();
		newCookies = mockHttpResponse.getNewCookies();
		errorMessage = mockHttpResponse.getErrorMessage();
		sentError = mockHttpResponse.isErrorSent();
		compareContent = true;
	}

	public byte[] getContent() {
		return content;
	}

	public void disableCompareContent() {
		compareContent = false;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		ComparableMockHttpResponse that = (ComparableMockHttpResponse) o;
		return status == that.status &&
			sentError == that.sentError &&
			((!compareContent) || Arrays.equals(getContent(), that.getContent())) &&
			Objects.equals(outputHeaders, that.outputHeaders) &&
			Objects.equals(newCookies, that.newCookies) &&
			Objects.equals(errorMessage, that.errorMessage);
	}

	@Override
	public String toString() {
		return "ComparableMockHttpResponse{" +
			"status=" + status +
			", content=" + new String(content, StandardCharsets.UTF_8) +
			", outputHeaders=" + outputHeaders +
			", newCookies=" + newCookies +
			", errorMessage='" + errorMessage + '\'' +
			", sentError=" + sentError +
			", compareContent=" + compareContent +
			'}';
	}
}