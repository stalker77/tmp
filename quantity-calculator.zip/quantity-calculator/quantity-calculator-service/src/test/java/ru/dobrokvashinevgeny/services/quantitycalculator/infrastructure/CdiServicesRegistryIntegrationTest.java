package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure;

import org.jboss.weld.junit5.*;
import org.junit.jupiter.api.Test;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsNull.notNullValue;

@EnableWeld
class CdiServicesRegistryIntegrationTest {
	@WeldSetup
	public WeldInitiator weldInitiator = WeldInitiator.from(
		CdiServicesRegistry.class, UnitsMockProducer.class, UnitTypesMockProducer.class
	).activate(ApplicationScoped.class).inject(this).build();

	@Inject
	private CdiServicesRegistry servicesRegistry;

	@Test
	void successfullyInjectServicesRegistry() {
		assertThat("quantityService", servicesRegistry.quantityService(), is(notNullValue()));
		assertThat("unitService", servicesRegistry.unitService(), is(notNullValue()));
	}
}