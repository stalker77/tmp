package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity;

import org.jboss.resteasy.mock.*;
import org.jboss.resteasy.spi.Dispatcher;
import org.jboss.weld.junit5.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.ServicesRegistry;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity.*;

import javax.inject.Inject;
import javax.ws.rs.core.*;
import java.nio.charset.StandardCharsets;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.ResourcesBootstrap.RESOURCES_BASE_PATH;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity.QuantityResource.HEALTH_RESOURCE_PATH;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity.QuantityResource.QUANTITY_CALCULATOR_RESOURCE_PATH;
import static ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.services.ObjectToJsonConverter.toJson;

@EnableWeld
@ExtendWith({BeforeAllTestsSmallRyeSetConfigForWorkaroundExtension.class})
class QuantityResourceIntegrationTest {
	private static final Response.Status HTTP_STATUS_OK = Response.Status.OK;
	private static final MediaType APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE =
		new MediaType("application", "json", StandardCharsets.UTF_8.name().toLowerCase());
	private static final double AMOUNT = 5;
	private static final String FROM_UNIT_ID = "м";
	private static final String TO_UNIT_ID = "км";
	private static final double CONVERTED_AMOUNT = AMOUNT * 0.001;
	private static final String EXCEPTION_CONTENT_ENCODING = "UTF-8";

	private MockRequestToResource requestToResource;

	@WeldSetup
	public WeldInitiator weldInitiator = WeldInitiator.from(
		QuantityResource.class, ServicesRegistryMockProducer.class
	).build();

	@Inject
	private QuantityResource quantityResource;

	@Inject
	private ServicesRegistry servicesRegistry;

	private QuantityService quantityService;

	@BeforeEach
	void setUp() {
		Dispatcher dispatcher = MockDispatcherFactory.createDispatcher();
		requestToResource = new MockRequestToResource(dispatcher);
		dispatcher.getRegistry().addSingletonResource(quantityResource);
		dispatcher.getProviderFactory().registerProvider(QuantityResourceExceptionMapper.class);

		quantityService = mock(QuantityService.class);
	}

	@Test
	void returnOkOnHealth() throws Exception {
		MockHttpRequest healthRequest = new RequestBuilder()
			.postRequestTo(RESOURCES_BASE_PATH + "/" + QUANTITY_CALCULATOR_RESOURCE_PATH + "/" + HEALTH_RESOURCE_PATH)
			.build();

		ComparableMockHttpResponse expectedHealthResponse = new ResponseBuilder()
			.httpStatus(HTTP_STATUS_OK)
			.build();


		ComparableMockHttpResponse healthResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(healthRequest));


		assertThat(healthResponse, equalTo(expectedHealthResponse));
	}

	@Test
	void returnsConvertedQuantityDescToSpecifiedUnitFromSpecifiedQuantityDesc() throws Exception {
		given(quantityService.convertQuantityToUnit(new QuantityDesc(AMOUNT, FROM_UNIT_ID), TO_UNIT_ID))
			.willReturn(new QuantityDesc(CONVERTED_AMOUNT, TO_UNIT_ID));
		given(servicesRegistry.quantityService()).willReturn(quantityService);

		MockHttpRequest convertRequest = new RequestBuilder()
			.postRequestTo(RESOURCES_BASE_PATH + "/" + QUANTITY_CALCULATOR_RESOURCE_PATH)
			.acceptMediaType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(toJson(new JaxbConvertQuantityOperationDesc(AMOUNT, FROM_UNIT_ID, TO_UNIT_ID)))
			.build();

		ComparableMockHttpResponse expectedConvertResponse = new ResponseBuilder()
			.httpStatus(HTTP_STATUS_OK)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(toJson(new JaxbQuantityDesc(CONVERTED_AMOUNT, TO_UNIT_ID)))
			.build();


		ComparableMockHttpResponse convertResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(convertRequest));


		assertThat(convertResponse, equalTo(expectedConvertResponse));
	}

	@Test
	void returnErrorCodeDuringConvertingWhenQuantityServiceFailed() throws Exception {
		given(quantityService.convertQuantityToUnit(new QuantityDesc(AMOUNT, FROM_UNIT_ID), TO_UNIT_ID))
			.willThrow(QuantityServiceException.class);
		given(servicesRegistry.quantityService()).willReturn(quantityService);

		MockHttpRequest convertRequest = new RequestBuilder()
			.postRequestTo(RESOURCES_BASE_PATH + "/" + QUANTITY_CALCULATOR_RESOURCE_PATH)
			.acceptMediaType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(toJson(new JaxbConvertQuantityOperationDesc(AMOUNT, FROM_UNIT_ID, TO_UNIT_ID)))
			.build();

		ComparableMockHttpResponse expectedConvertErrorResponse = new ResponseBuilder()
			.httpStatus(Response.Status.BAD_REQUEST)
			.contentEncoding(EXCEPTION_CONTENT_ENCODING)
			.contentType(APPLICATION_JAXB_WITH_UTF_CHARSET_CONTENT_TYPE)
			.content(QuantityServiceException.class.getCanonicalName() + "\n Подробная информация в логе.")
			.build();


		ComparableMockHttpResponse convertResponse =
			new ComparableMockHttpResponse(requestToResource.getAsyncResponseFor(convertRequest));


		assertThat(convertResponse, equalTo(expectedConvertErrorResponse));
	}
}