package ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

class QuantityServiceTest {
	private static final String FROM_UNIT_ID = "м";
	private static final String TO_UNIT_ID = "км";
	private static final double AMOUNT = 5;
	private static final double CONVERTED_AMOUNT = 0.005;
	private static final String NOT_EXISTS_UNIT_ID = "not_exists";
	private QuantityFactory quantityFactory;
	private Units units;

	@BeforeEach
	void setUp() {
		quantityFactory = mock(QuantityFactory.class);
		units = mock(Units.class);
	}

	@Test
	void returnsSameQuantityDescAsSpecifiedWhenConvertingToSameUnit() throws Exception {
		QuantityDesc fromQuantityDesc = new QuantityDesc(AMOUNT, FROM_UNIT_ID);

		QuantityService quantityService = new QuantityService(quantityFactory, units);


		ReadOnlyQuantityDesc convertedQuantityDesc
			= quantityService.convertQuantityToUnit(fromQuantityDesc, FROM_UNIT_ID);


		assertThat(convertedQuantityDesc, equalTo(fromQuantityDesc));
	}

	@Test
	void returnsConvertedQuantityDescToSpecifiedUnitFromSpecifiedQuantityDesc() throws Exception {
		QuantityDesc fromQuantityDesc = new QuantityDesc(AMOUNT, FROM_UNIT_ID);
		QuantityDesc expectedConvertedQuantityDesc = new QuantityDesc(CONVERTED_AMOUNT, TO_UNIT_ID);

		Unit toUnit = mock(Unit.class);
		given(units.unitOfId(TO_UNIT_ID)).willReturn(toUnit);

		Quantity fromQuantity = mock(Quantity.class);
		Quantity convertedQuantity = mock(Quantity.class);
		given(fromQuantity.convertTo(toUnit)).willReturn(convertedQuantity);
		given(quantityFactory.createQuantityBy(AMOUNT, FROM_UNIT_ID)).willReturn(fromQuantity);

		QuantityDesc filledQuantityDesc = new QuantityDesc();
		doAnswer(
			fillDesc -> {
				filledQuantityDesc.setAmount(CONVERTED_AMOUNT);
				filledQuantityDesc.setUnitId(TO_UNIT_ID);
				return null;
			}
		).when(convertedQuantity).fillQuantityDesc(filledQuantityDesc);

		QuantityService quantityService = new QuantityService(quantityFactory, units) {
			@Override
			QuantityDesc createEmptyConversationResult() {
				return filledQuantityDesc;
			}
		};


		ReadOnlyQuantityDesc convertedQuantityDesc
			= quantityService.convertQuantityToUnit(fromQuantityDesc, TO_UNIT_ID);


		assertThat(convertedQuantityDesc, equalTo(expectedConvertedQuantityDesc));
		then(quantityFactory).should().createQuantityBy(AMOUNT, FROM_UNIT_ID);
		then(units).should().unitOfId(TO_UNIT_ID);
		then(fromQuantity).should().convertTo(toUnit);
		then(convertedQuantity).should().fillQuantityDesc(filledQuantityDesc);
	}

	@Test
	void throwExceptionWhenUnitsFail() throws Exception {
		QuantityDesc fromQuantityDesc = new QuantityDesc(AMOUNT, FROM_UNIT_ID);

		given(units.unitOfId(NOT_EXISTS_UNIT_ID)).willThrow(UnitNotFoundException.class);

		QuantityService quantityService = new QuantityService(quantityFactory, units);


		assertThrows(
			QuantityServiceException.class,
			() -> quantityService.convertQuantityToUnit(fromQuantityDesc, NOT_EXISTS_UNIT_ID)
		);
	}

	@Test
	void throwExceptionWhenQuantityFactoryFail() throws Exception {
		QuantityDesc fromQuantityDesc = new QuantityDesc(AMOUNT, FROM_UNIT_ID);

		given(quantityFactory.createQuantityBy(AMOUNT, FROM_UNIT_ID)).willThrow(QuantityFactoryException.class);

		QuantityService quantityService = new QuantityService(quantityFactory, units);


		assertThrows(
			QuantityServiceException.class,
			() -> quantityService.convertQuantityToUnit(fromQuantityDesc, TO_UNIT_ID)
		);
	}

	@Test
	void throwExceptionWhenConversionFailed() throws Exception {
		QuantityDesc fromQuantityDesc = new QuantityDesc(AMOUNT, FROM_UNIT_ID);

		Unit toUnit = mock(Unit.class);
		given(units.unitOfId(TO_UNIT_ID)).willReturn(toUnit);

		Quantity fromQuantity = mock(Quantity.class);
		given(fromQuantity.convertTo(any(Unit.class))).willThrow(QuantityConvertException.class);
		given(quantityFactory.createQuantityBy(AMOUNT, FROM_UNIT_ID)).willReturn(fromQuantity);

		QuantityService quantityService = new QuantityService(quantityFactory, units);

		assertThrows(
			QuantityServiceException.class,
			() -> quantityService.convertQuantityToUnit(fromQuantityDesc, TO_UNIT_ID)
		);
	}
}