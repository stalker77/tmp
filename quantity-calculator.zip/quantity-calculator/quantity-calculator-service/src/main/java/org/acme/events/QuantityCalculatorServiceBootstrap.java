/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package org.acme.events;

import io.quarkus.runtime.StartupEvent;
import org.slf4j.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.UnitConversionRatio;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence.*;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class QuantityCalculatorServiceBootstrap {
	private static final Logger LOG = LoggerFactory.getLogger(QuantityCalculatorServiceBootstrap.class);
	private static final String DISTANCE_TYPE_ID = "distance";
	private static final String SPEED_TYPE_ID = "speed";

	@Inject
	private InMemoryUnits units;

	@Inject
	private InMemoryUnitConversionRatios unitConversionRatios;

	@Inject
	private InMemoryUnitTypes unitTypes;

	void onStart(@Observes StartupEvent startupEvent) {
		LOG.trace("Start onStart({})", startupEvent);

		try {
			unitTypes.add(new UnitType(DISTANCE_TYPE_ID, "Расстояние"));
			unitTypes.add(new UnitType("mass", "Масса"));
			unitTypes.add(new UnitType("time", "Время"));
			unitTypes.add(new UnitType(SPEED_TYPE_ID, "Скорость"));
			unitTypes.add(new UnitType("momentum", "Момент"));
			LOG.info("Unit types storage initialized.");

			units.add(new AtomicUnit("км", unitTypes.unitTypeOfId(DISTANCE_TYPE_ID), unitConversionRatios));
			units.add(new AtomicUnit("м", unitTypes.unitTypeOfId(DISTANCE_TYPE_ID), unitConversionRatios));
			units.add(new AtomicUnit("с", unitTypes.unitTypeOfId("time"), unitConversionRatios));
			units.add(new AtomicUnit("кг", unitTypes.unitTypeOfId("mass"), unitConversionRatios));

			units.add(
				new CompoundUnit(
					"1",
					unitTypes.unitTypeOfId("momentum"),
					List.of(units.unitOfId("кг"), units.unitOfId("м")),
					List.of(units.unitOfId("с"))
				)
			);
			units.add(
				new CompoundUnit(
					"2",
					unitTypes.unitTypeOfId(SPEED_TYPE_ID),
					List.of(units.unitOfId("м")),
					List.of(units.unitOfId("с")))
			);
			units.add(
				new CompoundUnit(
					"3",
					unitTypes.unitTypeOfId(SPEED_TYPE_ID),
					List.of(units.unitOfId("км")),
					List.of(units.unitOfId("с")))
			);
			LOG.info("Units storage initialized.");

			unitConversionRatios.add(
				new UnitConversionRatio(
					units.unitOfId("км"), units.unitOfId("м"), 1000
				)
			);
			LOG.info("Unit conversion ratios storage initialized.");
		} catch (UnitNotFoundException | UnitTypeNotFoundException e) {

		} finally {
			LOG.trace("End onStart()");
		}
	}
}