/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity;

import org.slf4j.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity.*;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path(QuantityResource.QUANTITY_CALCULATOR_RESOURCE_PATH)
public class QuantityResource {
	private static final Logger LOG = LoggerFactory.getLogger(QuantityResource.class);

	static final String QUANTITY_CALCULATOR_RESOURCE_PATH = "quantity";
	static final String HEALTH_RESOURCE_PATH = "health";

	@Inject
	private ServicesRegistry servicesRegistry;

	@POST
	@Consumes(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=utf-8;")
	@Produces(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=utf-8;")
	public JaxbQuantityDesc getConvertedQuantity(JaxbConvertQuantityOperationDesc convertQuantityOperationDesc)
		throws QuantityResourceException {
		LOG.trace("Start getConvertedQuantity({})", convertQuantityOperationDesc);

		QuantityService quantityService = servicesRegistry.quantityService();

		try {
			ReadOnlyQuantityDesc convertedQuantityDesc = quantityService.convertQuantityToUnit(
				new QuantityDesc(
					convertQuantityOperationDesc.getAmount(),
					convertQuantityOperationDesc.getFromUnitId()
				),
				convertQuantityOperationDesc.getToUnitId()
			);
			LOG.debug("Received new converted quantity descriptor: {}", convertedQuantityDesc);

			return new JaxbQuantityDesc(convertedQuantityDesc.getAmount(), convertedQuantityDesc.getUnitId());
		} catch (QuantityServiceException e) {
			LOG.error("Failed convert quantity by operation descriptor {}", convertQuantityOperationDesc, e);

			throw new QuantityResourceException(e);
		} finally {
			LOG.trace("End getConvertedQuantity()");
		}
	}

	@Path(HEALTH_RESOURCE_PATH)
	@POST
	public Response getHealth() {
		return Response.ok().build();
	}
}