/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.unit;

import java.util.*;

public class JaxbUnitTypeNamesDesc {
	private List<String> unitTypeNames;

	public JaxbUnitTypeNamesDesc() { /* NOP */ }

	public JaxbUnitTypeNamesDesc(List<String> unitTypeNames) {
		this.unitTypeNames = unitTypeNames;
	}

	public List<String> getUnitTypeNames() {
		return unitTypeNames;
	}

	public void setUnitTypeNames(List<String> unitTypeNames) {
		this.unitTypeNames = unitTypeNames;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		JaxbUnitTypeNamesDesc that = (JaxbUnitTypeNamesDesc) o;
		return Objects.equals(getUnitTypeNames(), that.getUnitTypeNames());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getUnitTypeNames());
	}

	@Override
	public String toString() {
		return "JaxbUnitTypeNamesDesc{" +
			"unitTypeNames=" + unitTypeNames +
			'}';
	}
}