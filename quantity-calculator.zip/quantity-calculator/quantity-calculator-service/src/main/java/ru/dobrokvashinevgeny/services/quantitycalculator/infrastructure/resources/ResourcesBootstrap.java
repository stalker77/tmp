/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath(ResourcesBootstrap.RESOURCES_BASE_PATH)
public class ResourcesBootstrap extends Application {
	public static final String RESOURCES_BASE_PATH = "rest";
}