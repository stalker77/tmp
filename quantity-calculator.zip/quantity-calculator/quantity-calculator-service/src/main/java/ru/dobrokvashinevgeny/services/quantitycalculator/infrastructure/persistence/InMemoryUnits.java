/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import javax.enterprise.context.ApplicationScoped;
import java.util.*;

import static java.util.stream.Collectors.toList;

@ApplicationScoped
public class InMemoryUnits implements Units {
	private List<Unit> unitStore = new ArrayList<>();

	public int size() {
		return unitStore.size();
	}

	public void add(Unit unit) {
		unitStore.add(unit);
	}

	@Override
	public Unit unitOfId(String unitId) throws UnitNotFoundException {
		return unitStore
			.stream()
			.filter(unit -> unit.unitId().equalsIgnoreCase(unitId))
			.findFirst().orElseThrow(() -> new UnitNotFoundException(""));
	}

	@Override
	public List<Unit> unitsOfType(UnitType unitType) {
		return unitStore
			.stream()
			.filter(unit -> unit.isTypeOf(unitType))
			.collect(toList());
	}
}