/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity;

import java.util.Objects;

public class JaxbQuantityDesc {
	private double amount;
	private String unitId;

	public JaxbQuantityDesc() { /* NOP */ }

	public JaxbQuantityDesc(double amount, String unitId) {
		this.amount = amount;
		this.unitId = unitId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		JaxbQuantityDesc that = (JaxbQuantityDesc) o;
		return Double.compare(that.getAmount(), getAmount()) == 0 &&
			getUnitId().equals(that.getUnitId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getAmount(), getUnitId());
	}

	@Override
	public String toString() {
		return "JaxbQuantityDesc{" +
			"amount=" + amount +
			", unitId='" + unitId + '\'' +
			'}';
	}
}