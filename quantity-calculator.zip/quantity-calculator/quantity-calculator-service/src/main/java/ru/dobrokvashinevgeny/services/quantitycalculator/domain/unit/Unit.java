/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import java.util.*;

public abstract class Unit {
	private final String unitId;
	private final UnitType unitType;

	protected Unit(String unitId, UnitType unitType) {
		this.unitId = unitId;
		this.unitType = unitType;
	}

	public abstract double getConversionRatioTo(Unit toUnit) throws UnitConversionException;

	public String unitId() {
		return this.unitId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		Unit unit = (Unit) o;
		return unitId.equals(unit.unitId) &&
			unitType.equals(unit.unitType);
	}

	@Override
	public int hashCode() {
		return Objects.hash(unitId, unitType);
	}

	abstract List<Unit> directUnitList();

	abstract List<Unit> inverseUnitList();

	public abstract String formattedValue();

	@Override
	public String toString() {
		return "Unit{" +
			"unitId='" + unitId + '\'' +
			", unitType=" + unitType +
			'}';
	}

	public boolean isTypeOf(UnitType unitType) {
		return this.unitType.equals(unitType);
	}
}