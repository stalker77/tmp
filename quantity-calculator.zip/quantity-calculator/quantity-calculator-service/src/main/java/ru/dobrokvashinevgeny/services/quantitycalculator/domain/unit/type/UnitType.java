/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type;

import java.util.Objects;

public class UnitType {
	private final String unitTypeId;
	private final String unitTypeName;

	public UnitType(String unitTypeId, String unitTypeName) {
		this.unitTypeId = unitTypeId;
		this.unitTypeName = unitTypeName;
	}

	public String getUnitTypeId() {
		return unitTypeId;
	}

	public String getUnitTypeName() {
		return unitTypeName;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		UnitType unitType = (UnitType) o;
		return getUnitTypeId().equals(unitType.getUnitTypeId()) &&
			getUnitTypeName().equals(unitType.getUnitTypeName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getUnitTypeId(), getUnitTypeName());
	}

	@Override
	public String toString() {
		return "UnitType{" +
			"unitTypeId='" + unitTypeId + '\'' +
			", unitTypeName='" + unitTypeName + '\'' +
			'}';
	}
}