/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.Unit;

public interface UnitConversionRatios {
	UnitConversionRatio conversionRatioOf(Unit fromUnit, Unit toUnit) throws ConversionRatioNotFoundException;
}