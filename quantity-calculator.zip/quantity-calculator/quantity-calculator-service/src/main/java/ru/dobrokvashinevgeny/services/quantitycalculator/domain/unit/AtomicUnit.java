/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import java.util.*;

public class AtomicUnit extends Unit {
	private final UnitConversionRatios unitConversionRatios;

	public AtomicUnit(String unitId, UnitType unitType, UnitConversionRatios unitConversionRatios) {
		super(unitId, unitType);
		this.unitConversionRatios = unitConversionRatios;
	}

	@Override
	public double getConversionRatioTo(Unit toUnit) throws UnitConversionException {
		if (this.equals(toUnit)) {
			return 1.0;
		}

		if (getClass() != toUnit.getClass()) {
			throw new UnitConversionException("Can't convert to unit: " + toUnit);
		}

		double ratioValue;
		try {
			ratioValue = getRatioValueTo(toUnit);
		} catch (ConversionRatioNotFoundException e) {
			ratioValue = getInverseRatioValueTo(toUnit);
		}

		return ratioValue;
	}

	private double getRatioValueTo(Unit toUnit) throws ConversionRatioNotFoundException {
		UnitConversionRatio conversionRatio = unitConversionRatios.conversionRatioOf(this, toUnit);

		return conversionRatio.getRatioValue();
	}

	private double getInverseRatioValueTo(Unit toUnit) throws UnitConversionException {
		try {
			UnitConversionRatio conversionRatio = unitConversionRatios.conversionRatioOf(toUnit, this);

			return 1.0 / conversionRatio.getRatioValue();
		} catch (ConversionRatioNotFoundException e) {
			throw new UnitConversionException(e);
		}
	}

	@Override
	public List<Unit> directUnitList() {
		return List.of(this);
	}

	@Override
	public List<Unit> inverseUnitList() {
		return Collections.emptyList();
	}

	@Override
	public String formattedValue() {
		return unitId();
	}
}