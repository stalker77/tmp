/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.*;

@Provider
public class QuantityResourceExceptionMapper implements ExceptionMapper<QuantityResourceException> {
	private static final String EXCEPTION_RESPONSE_ENCODING = "UTF-8";

	@Override
	public Response toResponse(QuantityResourceException exception) {
		return Response
			.status(Response.Status.BAD_REQUEST)
			.encoding(EXCEPTION_RESPONSE_ENCODING)
			.entity(exception.getMessage() + "\n Подробная информация в логе.")
			.build();
	}
}