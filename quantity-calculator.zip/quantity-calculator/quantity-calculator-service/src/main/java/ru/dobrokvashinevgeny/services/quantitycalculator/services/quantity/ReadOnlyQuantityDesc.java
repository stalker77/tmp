package ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity;

public interface ReadOnlyQuantityDesc {
	double getAmount();

	String getUnitId();
}