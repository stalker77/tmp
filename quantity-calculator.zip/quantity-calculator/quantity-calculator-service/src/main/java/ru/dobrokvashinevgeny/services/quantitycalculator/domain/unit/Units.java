package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import java.util.List;

public interface Units {
	Unit unitOfId(String unitId) throws UnitNotFoundException;

	List<Unit> unitsOfType(UnitType unitType);
}