/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity.QuantityFactory;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.Units;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitTypes;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity.QuantityService;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.unit.UnitService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class CdiServicesRegistry implements ServicesRegistry {
	private QuantityService quantityService;

	private UnitService unitService;

	@Inject
	private Units units;

	@Inject
	private UnitTypes unitTypes;

	@Override
	public QuantityService quantityService() {
		return quantityService;
	}

	@Override
	public UnitService unitService() {
		return unitService;
	}

	@PostConstruct
	public void init() {
		this.quantityService = new QuantityService(new QuantityFactory(units), units);

		this.unitService = new UnitService(unitTypes, units);
	}
}