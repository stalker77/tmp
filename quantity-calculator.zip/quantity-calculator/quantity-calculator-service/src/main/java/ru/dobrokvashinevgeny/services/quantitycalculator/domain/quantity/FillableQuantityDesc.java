package ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity;

public interface FillableQuantityDesc {
	void setAmount(double amount);

	void setUnitId(String unitId);
}