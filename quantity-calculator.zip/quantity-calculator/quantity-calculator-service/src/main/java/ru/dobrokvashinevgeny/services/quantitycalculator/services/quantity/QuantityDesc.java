/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity.FillableQuantityDesc;

import java.util.Objects;

public class QuantityDesc implements ReadOnlyQuantityDesc, FillableQuantityDesc {
	private double amount;
	private String unitId;

	public QuantityDesc() {
	}

	public QuantityDesc(double amount, String unitId) {
		this.amount = amount;
		this.unitId = unitId;
	}

	@Override
	public double getAmount() {
		return amount;
	}

	@Override
	public String getUnitId() {
		return unitId;
	}

	@Override
	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		QuantityDesc that = (QuantityDesc) o;
		return Double.compare(that.getAmount(), getAmount()) == 0 &&
			Objects.equals(getUnitId(), that.getUnitId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getAmount(), getUnitId());
	}

	@Override
	public String toString() {
		return "QuantityDesc{" +
			"amount=" + amount +
			", unitId='" + unitId + '\'' +
			'}';
	}
}