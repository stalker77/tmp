/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity;

import org.slf4j.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;

public class QuantityService {
	private static final Logger LOG = LoggerFactory.getLogger(QuantityService.class);

	private final QuantityFactory quantityFactory;
	private final Units units;

	public QuantityService(QuantityFactory quantityFactory, Units units) {
		this.quantityFactory = quantityFactory;
		this.units = units;
	}

	public ReadOnlyQuantityDesc convertQuantityToUnit(QuantityDesc fromQuantityDesc, String toUnitId)
		throws QuantityServiceException {
		LOG.trace("Start convertQuantityToUnit({}, {})", fromQuantityDesc, toUnitId);

		if (fromQuantityDesc.getUnitId().equals(toUnitId)) {
			return fromQuantityDesc;
		}

		try {
			Quantity quantity = quantityFactory.createQuantityBy(
				fromQuantityDesc.getAmount(),
				fromQuantityDesc.getUnitId()
			);
			LOG.debug("Created quantity: {} by descriptor: {}", quantity, fromQuantityDesc);

			Unit toUnit = units.unitOfId(toUnitId);
			LOG.debug("Received unit: {} by id: {}", toUnit, toUnitId);

			Quantity convertedQuantity = quantity.convertTo(toUnit);
			LOG.debug("Created converted quantity: {} to unit: {}", convertedQuantity, toUnit);

			QuantityDesc conversationResult = createEmptyConversationResult();
			convertedQuantity.fillQuantityDesc(conversationResult);
			LOG.debug("Created conversation result: {}", conversationResult);

			return conversationResult;
		} catch (UnitNotFoundException | QuantityFactoryException | QuantityConvertException e) {
			throw new QuantityServiceException(e);
		} finally {
			LOG.trace("End convertQuantityToUnit()");
		}
	}

	QuantityDesc createEmptyConversationResult() {
		return new QuantityDesc();
	}
}