/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.unit;

import org.slf4j.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.ServicesRegistry;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.unit.*;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path(UnitResource.UNIT_RESOURCE_PATH)
public class UnitResource {
	private static final Logger LOG = LoggerFactory.getLogger(UnitResource.class);

	static final String UNIT_RESOURCE_PATH = "unit";
	static final String TYPE_PATH = "type";
	static final String UNIT_TYPE_ID = "unitTypeId";

	@Inject
	private ServicesRegistry servicesRegistry;

	@Path(TYPE_PATH)
	@GET
	@Produces(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=utf-8;")
	public JaxbUnitTypeNamesDesc getListOfExistingUnitTypes() {
		LOG.trace("Start getListOfExistingUnitTypes()");

		UnitService unitService = servicesRegistry.unitService();

		try {
			var unitTypeNames = unitService.getUnitTypeNames();
			LOG.debug("Received unit type names: {}", unitTypeNames);

			return new JaxbUnitTypeNamesDesc(unitTypeNames.getUnitTypeNames());
		} finally {
			LOG.trace("End getListOfExistingUnitTypes()");
		}
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=utf-8;")
	public JaxbUnitFormattedValuesDesc getListOfUnitFormattedValues(@QueryParam(UNIT_TYPE_ID) String unitTypeId)
		throws UnitResourceException {
		LOG.trace("Start getListOfUnitFormattedValues({})", unitTypeId);

		UnitService unitService = servicesRegistry.unitService();

		try {
			UnitFormattedValuesDesc unitFormattedValuesDesc
				= unitService.getUnitFormattedValuesOfUnitTypeId(unitTypeId);

			return new JaxbUnitFormattedValuesDesc(unitFormattedValuesDesc.getUnitFormattedValues());
		} catch (UnitServiceException e) {
			LOG.error("Failed get list of unit formatted values by unit type id: {}", unitTypeId, e);

			throw new UnitResourceException(e);
		} finally {
			LOG.trace("End getListOfUnitFormattedValues()");
		}
	}
}