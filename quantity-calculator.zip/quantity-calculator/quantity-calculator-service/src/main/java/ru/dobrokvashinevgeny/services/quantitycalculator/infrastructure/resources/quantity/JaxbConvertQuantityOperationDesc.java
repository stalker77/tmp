/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.quantity;

import java.util.Objects;

public class JaxbConvertQuantityOperationDesc {
	private double amount;
	private String fromUnitId;
	private String toUnitId;

	public JaxbConvertQuantityOperationDesc() { /* NOP */ }

	public JaxbConvertQuantityOperationDesc(double amount, String fromUnitId, String toUnitId) {
		this.amount = amount;
		this.fromUnitId = fromUnitId;
		this.toUnitId = toUnitId;
	}

	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getFromUnitId() {
		return fromUnitId;
	}

	public void setFromUnitId(String fromUnitId) {
		this.fromUnitId = fromUnitId;
	}

	public String getToUnitId() {
		return toUnitId;
	}

	public void setToUnitId(String toUnitId) {
		this.toUnitId = toUnitId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		JaxbConvertQuantityOperationDesc that = (JaxbConvertQuantityOperationDesc) o;
		return Double.compare(that.getAmount(), getAmount()) == 0 &&
			getFromUnitId().equals(that.getFromUnitId()) &&
			getToUnitId().equals(that.getToUnitId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getAmount(), getFromUnitId(), getToUnitId());
	}

	@Override
	public String toString() {
		return "JaxbConvertQuantityOperationDesc{" +
			"amount=" + amount +
			", fromUnitId='" + fromUnitId + '\'' +
			", toUnitId='" + toUnitId + '\'' +
			'}';
	}
}