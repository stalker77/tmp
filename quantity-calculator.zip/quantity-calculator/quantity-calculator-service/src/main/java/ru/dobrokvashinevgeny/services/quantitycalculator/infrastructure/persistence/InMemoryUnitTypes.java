/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.*;

import javax.enterprise.context.ApplicationScoped;
import java.util.*;

@ApplicationScoped
public class InMemoryUnitTypes implements UnitTypes {
	private List<UnitType> unitTypeStore = new ArrayList<>();

	public int size() {
		return unitTypeStore.size();
	}

	public void add(UnitType unitType) {
		unitTypeStore.add(unitType);
	}

	@Override
	public UnitType unitTypeOfId(String unitTypeId) throws UnitTypeNotFoundException {
		return unitTypeStore
			.stream()
			.filter(unitType -> unitType.getUnitTypeId().equals(unitTypeId))
			.findFirst().orElseThrow(() -> new UnitTypeNotFoundException(""));
	}

	@Override
	public List<UnitType> unitTypeList() {
		return new ArrayList<>(unitTypeStore);
	}
}