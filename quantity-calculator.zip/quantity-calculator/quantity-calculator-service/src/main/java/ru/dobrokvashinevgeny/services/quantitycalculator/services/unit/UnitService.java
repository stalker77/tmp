/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.services.unit;

import org.slf4j.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.*;

import java.util.List;

import static java.util.stream.Collectors.toList;

public class UnitService {
	private static final Logger LOG = LoggerFactory.getLogger(UnitService.class);

	private final UnitTypes unitTypes;
	private final Units units;

	public UnitService(UnitTypes unitTypes, Units units) {
		this.unitTypes = unitTypes;
		this.units = units;
	}

	public UnitTypeNamesDesc getUnitTypeNames() {
		final List<String> unitTypeNames
			= unitTypes.unitTypeList()
				.stream()
				.map(UnitType::getUnitTypeName)
				.collect(toList());

		return new UnitTypeNamesDesc(unitTypeNames);
	}

	public UnitFormattedValuesDesc getUnitFormattedValuesOfUnitTypeId(String unitTypeId) throws UnitServiceException {
		try {
			var unitType = unitTypes.unitTypeOfId(unitTypeId);

			var unitsOfTypeFormattedValues
				= units.unitsOfType(unitType)
				.stream()
				.map(Unit::formattedValue)
				.collect(toList());

			return new UnitFormattedValuesDesc(unitsOfTypeFormattedValues);
		} catch (UnitTypeNotFoundException e) {
			throw new UnitServiceException(e);
		}
	}
}