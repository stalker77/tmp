/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.persistence;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.Unit;
import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio.*;

import javax.enterprise.context.ApplicationScoped;
import java.util.*;

@ApplicationScoped
public class InMemoryUnitConversionRatios implements UnitConversionRatios {
	private List<UnitConversionRatio> unitConversionRatioStore = new ArrayList<>();

	public int size() {
		return unitConversionRatioStore.size();
	}

	public void add(UnitConversionRatio unitConversionRatio) {
		unitConversionRatioStore.add(unitConversionRatio);
	}

	@Override
	public UnitConversionRatio conversionRatioOf(Unit fromUnit, Unit toUnit) throws ConversionRatioNotFoundException {
		return
			unitConversionRatioStore
				.stream()
				.filter(unitConversionRatio -> unitConversionRatio.getFromUnit().equals(fromUnit)
											&& unitConversionRatio.getToUnit().equals(toUnit))
				.findFirst().orElseThrow(() -> new ConversionRatioNotFoundException(""));
	}
}