/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;

public class QuantityFactory {
	private final Units units;

	public QuantityFactory(Units units) {
		this.units = units;
	}

	public Quantity createQuantityBy(double amount, String unitId) throws QuantityFactoryException {
		try {
			return new Quantity(amount, units.unitOfId(unitId));
		} catch (UnitNotFoundException e) {
			throw new QuantityFactoryException(e);
		}
	}
}