package ru.dobrokvashinevgeny.services.quantitycalculator.services;

import ru.dobrokvashinevgeny.services.quantitycalculator.services.quantity.QuantityService;
import ru.dobrokvashinevgeny.services.quantitycalculator.services.unit.UnitService;

public interface ServicesRegistry {
	QuantityService quantityService();

	UnitService unitService();
}