/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.quantity;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.*;

import java.util.Objects;

public class Quantity {
	private final double amount;
	private final Unit unit;

	Quantity(double amount, Unit unit) {
		this.amount = amount;
		this.unit = unit;
	}

	public Quantity convertTo(Unit toUnit) throws QuantityConvertException {
		if (this.unit.equals(toUnit)) {
			return new Quantity(amount, unit);
		}

		try {
			return new Quantity(amount * unit.getConversionRatioTo(toUnit), toUnit);
		} catch (UnitConversionException e) {
			throw new QuantityConvertException(e);
		}
	}

	public void fillQuantityDesc(FillableQuantityDesc fillableQuantityDesc) {
		fillableQuantityDesc.setAmount(amount);
		fillableQuantityDesc.setUnitId(unit.unitId());
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		Quantity quantity = (Quantity) o;
		return Double.compare(quantity.amount, amount) == 0 &&
			unit.equals(quantity.unit);
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, unit);
	}

	@Override
	public String toString() {
		return "Quantity{" +
			"amount=" + amount +
			", unit=" + unit +
			'}';
	}
}