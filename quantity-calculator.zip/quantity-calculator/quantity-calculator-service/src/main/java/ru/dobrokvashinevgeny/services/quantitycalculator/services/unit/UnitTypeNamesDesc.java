/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.services.unit;

import java.util.*;

public class UnitTypeNamesDesc {
	private final List<String> unitTypeNames;

	public UnitTypeNamesDesc(List<String> unitTypeNames) {
		this.unitTypeNames = unitTypeNames;
	}

	public List<String> getUnitTypeNames() {
		return unitTypeNames;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		UnitTypeNamesDesc that = (UnitTypeNamesDesc) o;
		return getUnitTypeNames().equals(that.getUnitTypeNames());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getUnitTypeNames());
	}

	@Override
	public String toString() {
		return "UnitTypeNamesDesc{" +
			"unitTypeNames=" + unitTypeNames +
			'}';
	}
}