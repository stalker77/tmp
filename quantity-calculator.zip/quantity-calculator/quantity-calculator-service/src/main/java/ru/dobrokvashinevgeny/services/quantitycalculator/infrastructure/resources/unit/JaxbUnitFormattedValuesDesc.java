/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.infrastructure.resources.unit;

import java.util.*;

public class JaxbUnitFormattedValuesDesc {
	private List<String> unitFormattedValues;

	public JaxbUnitFormattedValuesDesc() { /* NOP */ }

	public JaxbUnitFormattedValuesDesc(List<String> unitFormattedValues) {
		this.unitFormattedValues = unitFormattedValues;
	}

	public List<String> getUnitFormattedValues() {
		return unitFormattedValues;
	}

	public void setUnitFormattedValues(List<String> unitFormattedValues) {
		this.unitFormattedValues = unitFormattedValues;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		JaxbUnitFormattedValuesDesc that = (JaxbUnitFormattedValuesDesc) o;
		return getUnitFormattedValues().equals(that.getUnitFormattedValues());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getUnitFormattedValues());
	}

	@Override
	public String toString() {
		return "JaxbUnitFormattedValuesDesc{" +
			"unitFormattedValues=" + unitFormattedValues +
			'}';
	}
}