/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.ratio;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.Unit;

import java.util.Objects;

public class UnitConversionRatio {
	private final Unit fromUnit;
	private final Unit toUnit;
	private double ratioValue;

	public UnitConversionRatio(Unit fromUnit, Unit toUnit, double ratioValue) {
		this.fromUnit = fromUnit;
		this.toUnit = toUnit;
		this.ratioValue = ratioValue;
	}

	public Unit getFromUnit() {
		return fromUnit;
	}

	public Unit getToUnit() {
		return toUnit;
	}

	public double getRatioValue() {
		return ratioValue;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		UnitConversionRatio that = (UnitConversionRatio) o;
		return Double.compare(that.getRatioValue(), getRatioValue()) == 0 &&
			getFromUnit().equals(that.getFromUnit()) &&
			getToUnit().equals(that.getToUnit());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getFromUnit(), getToUnit(), getRatioValue());
	}

	@Override
	public String toString() {
		return "UnitConversionRatio{" +
			"fromUnit=" + fromUnit +
			", toUnit=" + toUnit +
			", ratioValue=" + ratioValue +
			'}';
	}
}