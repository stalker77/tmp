package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type;

import java.util.List;

public interface UnitTypes {
	UnitType unitTypeOfId(String unitTypeId) throws UnitTypeNotFoundException;

	List<UnitType> unitTypeList();
}