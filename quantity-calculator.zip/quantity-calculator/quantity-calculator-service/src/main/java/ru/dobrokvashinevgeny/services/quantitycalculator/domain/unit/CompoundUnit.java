/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit;

import ru.dobrokvashinevgeny.services.quantitycalculator.domain.unit.type.UnitType;

import java.util.*;

import static java.util.stream.Collectors.joining;

public class CompoundUnit extends Unit {
	private static final String UNIT_DELIMITER = "*";
	static final String FORMAT_OF_UNIT_VALUE = "%s/%s";

	private final List<Unit> directUnits;
	private final List<Unit> inverseUnits;

	public CompoundUnit(String unitId, UnitType unitType, List<Unit> directUnits, List<Unit> inverseUnits) {
		super(unitId, unitType);
		this.directUnits = directUnits;
		this.inverseUnits = inverseUnits;
	}

	@Override
	public double getConversionRatioTo(Unit toUnit) throws UnitConversionException {
		if (this.equals(toUnit)) {
			return 1.0;
		}

		if (getClass() != toUnit.getClass()
			|| directUnits.size() != toUnit.directUnitList().size()
			|| inverseUnits.size() != toUnit.inverseUnitList().size()) {
			throw new UnitConversionException("Can't convert to unit: " + toUnit);
		}

		int directUnitIndex = 0;
		double directUnitsRatio = 1.0;
		for (Unit directUnit : directUnits) {
			directUnitsRatio *= directUnit.getConversionRatioTo(toUnit.directUnitList().get(directUnitIndex++));
		}

		int inverseUnitIndex = 0;
		double inverseUnitsRatio = 1.0;
		for (Unit inverseUnit : inverseUnits) {
			inverseUnitsRatio *= inverseUnit.getConversionRatioTo(toUnit.inverseUnitList().get(inverseUnitIndex++));
		}

		return directUnitsRatio / inverseUnitsRatio;
	}

	@Override
	public List<Unit> directUnitList() {
		return new ArrayList<>(directUnits);
	}

	@Override
	public List<Unit> inverseUnitList() {
		return new ArrayList<>(inverseUnits);
	}

	@Override
	public String formattedValue() {
		return String.format(FORMAT_OF_UNIT_VALUE, formatUnitList(directUnits), formatUnitList(inverseUnits));
	}

	private String formatUnitList(List<Unit> unitList) {
		return
			unitList
				.stream()
				.map(Unit::formattedValue)
				.collect(joining(UNIT_DELIMITER));
	}
}