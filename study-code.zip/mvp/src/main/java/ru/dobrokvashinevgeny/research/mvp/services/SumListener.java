package ru.dobrokvashinevgeny.research.mvp.services;

public interface SumListener {
	void sumCalculated(int sumValue);
}