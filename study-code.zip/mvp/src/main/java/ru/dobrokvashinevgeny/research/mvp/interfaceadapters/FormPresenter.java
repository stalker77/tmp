/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.interfaceadapters;

import ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation.form.*;
import ru.dobrokvashinevgeny.research.mvp.services.*;

public class FormPresenter implements InputDataListener {
	private AdditionTwoNumbersFormView view;
	private NumberService model;

	public FormPresenter(AdditionTwoNumbersFormView view, NumberService model) {
		setView(view);
		setModel(model);
	}

	private void setView(AdditionTwoNumbersFormView view) {
		this.view = view;
		this.view.addInputDataListener(this);
	}

	private void setModel(NumberService model) {
		this.model = model;
		this.model.addSumOfTwoIntegersListener(modelListener);
	}

	private SumListener modelListener = new SumListener() {
		@Override
		public void sumCalculated(int sumValue) {
			view.setResult(sumValue);
		}
	};

	@Override
	public void inputDataEntered() throws InputDataListenerException {
		try {
			IntegerNumberDesc firstNumber = IntegerNumberDesc.createFromStringValue(this.view.getFirstInputValue());
			IntegerNumberDesc secondNumber = IntegerNumberDesc.createFromStringValue(this.view.getSecondInputValue());

			model.calculateSumOfTwoIntegers(firstNumber, secondNumber);
		} catch (NumberConvertException e) {
			throw new InputDataListenerException(e);
		}
	}
}