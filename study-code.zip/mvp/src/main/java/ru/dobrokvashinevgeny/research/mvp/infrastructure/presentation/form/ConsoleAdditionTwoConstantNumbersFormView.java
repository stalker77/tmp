/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation.form;

import ru.dobrokvashinevgeny.research.mvp.interfaceadapters.AdditionTwoNumbersFormView;

import java.util.*;

public class ConsoleAdditionTwoConstantNumbersFormView implements AdditionTwoNumbersFormView {
	private static final String FIRST_INPUT = "23";
	private static final String SECOND_INPUT = "-7";

	private String firstInputValue = FIRST_INPUT;
	private String secondInputValue = SECOND_INPUT;

	private List<InputDataListener> listeners = new ArrayList<>();

	@Override
	public void addInputDataListener(InputDataListener listener) {
		this.listeners.add(listener);
	}

	@Override
	public void removeInputDataListener(InputDataListener listener) {
		this.listeners.remove(listener);
	}

	@Override
	public String getFirstInputValue() {
		return this.firstInputValue;
	}

	@Override
	public String getSecondInputValue() {
		return this.secondInputValue;
	}

	@Override
	public void show() throws InputDataListenerException {
		System.out.println("Программа сложения 2-ух целых чисел:");

		System.out.print("1-е число: ");
		System.out.println(this.firstInputValue);

		System.out.print("2-е число: ");
		System.out.println(this.secondInputValue);

		fireInputDataEntered();
	}

	private void fireInputDataEntered() throws InputDataListenerException {
		for (InputDataListener listener : listeners) {
			listener.inputDataEntered();
		}
	}

	@Override
	public void setResult(int sumValue) {
		System.out.println("Результат: " + this.firstInputValue + " + " + this.secondInputValue + " = " + sumValue);
	}
}