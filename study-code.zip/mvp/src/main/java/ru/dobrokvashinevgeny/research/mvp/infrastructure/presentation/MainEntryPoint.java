/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation;

import ru.dobrokvashinevgeny.research.mvp.infrastructure.*;

public class MainEntryPoint {
	public static void main(String[] args) {
		ConsoleAppForAdditionTwoNumbers application = Applications.createConsoleApp();
		application.run();
	}
}