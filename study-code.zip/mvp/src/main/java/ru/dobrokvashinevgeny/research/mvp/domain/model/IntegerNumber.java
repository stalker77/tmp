/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.domain.model;

public class IntegerNumber {
	private final int value;

	public IntegerNumber(int integerNumberValue) {
		this.value = integerNumberValue;
	}

	public IntegerNumber add(IntegerNumber anotherIntegerNumber) {
		return new IntegerNumber(value + anotherIntegerNumber.getValue());
	}

	public int getValue() {
		return value;
	}
}