/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation.form;

import ru.dobrokvashinevgeny.research.mvp.interfaceadapters.AdditionTwoNumbersFormView;

import java.io.*;
import java.util.*;

public class ConsoleAdditionTwoNumbersFormView implements AdditionTwoNumbersFormView {
	private String firstInputValue;

	private String secondInputValue;

	private List<InputDataListener> listeners = new ArrayList<>();

	@Override
	public void addInputDataListener(InputDataListener listener) {
		this.listeners.add(listener);
	}

	@Override
	public void removeInputDataListener(InputDataListener listener) {
		this.listeners.remove(listener);
	}

	@Override
	public String getFirstInputValue() {
		return this.firstInputValue;
	}

	@Override
	public String getSecondInputValue() {
		return this.secondInputValue;
	}

	@Override
	public void show() throws InputDataException {
		System.out.println("Программа сложения 2-ух целых чисел:\n");

		boolean inputValuesValid = false;
		while (!inputValuesValid) {
			this.firstInputValue = inputValueWithPrompt("Введите 1-е число: ");

			this.secondInputValue = inputValueWithPrompt("Введите 2-е число: ");

			try {
				fireInputDataEntered();
				inputValuesValid = true;
			} catch (InputDataListenerException e) {
				System.out.println("\nВы ввели числа неверного формата, повторите ввод:");
			}
		}
	}

	private String inputValueWithPrompt(String prompt) throws InputDataException {
		System.out.print(prompt);

		try {
			BufferedReader inputValueReader = new BufferedReader(new InputStreamReader(System.in));
			String result = inputValueReader.readLine();

			return result;
		} catch (IOException e) {
			throw new InputDataException(e);
		}
	}

	private void fireInputDataEntered() throws InputDataListenerException {
		for (InputDataListener listener : listeners) {
			listener.inputDataEntered();
		}
	}

	@Override
	public void setResult(int sumValue) {
		System.out.println("Результат: " + this.firstInputValue + " + " + this.secondInputValue + " = " + sumValue);
	}
}