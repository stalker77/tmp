package ru.dobrokvashinevgeny.research.mvp.interfaceadapters;

import ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation.form.*;

public interface AdditionTwoNumbersFormView {
	void addInputDataListener(InputDataListener listener);

	void removeInputDataListener(InputDataListener listener);

	String getFirstInputValue();

	String getSecondInputValue();

	void show() throws InputDataListenerException, InputDataException;

	void setResult(int sumValue);
}