/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.infrastructure;

public class Applications {
	public static ConsoleAppForAdditionTwoNumbers createConsoleApp() {
		return new ConsoleAppForAdditionTwoNumbers();
	}
}