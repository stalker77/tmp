/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvp.infrastructure;

import ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation.form.*;
import ru.dobrokvashinevgeny.research.mvp.interfaceadapters.*;
import ru.dobrokvashinevgeny.research.mvp.services.*;

import java.util.logging.*;

public class ConsoleAppForAdditionTwoNumbers {
	private final static Logger LOG = Logger.getLogger(ConsoleAppForAdditionTwoNumbers.class.getName());
	private final FormPresenter mainFormPresenter;
	private final AdditionTwoNumbersFormView mainForm;

	public ConsoleAppForAdditionTwoNumbers() {
		this.mainForm = new ConsoleAdditionTwoNumbersFormView();
//		this.mainForm = new ConsoleAdditionTwoConstantNumbersFormView();
		this.mainFormPresenter = new FormPresenter(mainForm, new NumberService());
	}

	public void run() {
		try {
			mainForm.show();
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "", e);
		}
	}
}