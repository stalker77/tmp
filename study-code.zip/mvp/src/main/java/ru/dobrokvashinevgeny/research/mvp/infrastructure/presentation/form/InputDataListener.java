package ru.dobrokvashinevgeny.research.mvp.infrastructure.presentation.form;

public interface InputDataListener {
	void inputDataEntered() throws InputDataListenerException;
}