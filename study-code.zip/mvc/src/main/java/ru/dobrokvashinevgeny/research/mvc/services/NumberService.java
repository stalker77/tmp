/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvc.services;

import ru.dobrokvashinevgeny.research.mvc.domain.model.IntegerNumber;

import java.util.*;

public class NumberService {
	private final List<SumListener> sumListeners;

	public NumberService() {
		this.sumListeners = new ArrayList<>();
	}

	public void addSumOfTwoIntegersListener(SumListener listener) {
		sumListeners.add(listener);
	}

	public void removeSumOfTwoIntegersListener(SumListener listener) {
		sumListeners.remove(listener);
	}

	public void calculateSumOfTwoIntegers(IntegerNumberDesc firstInteger, IntegerNumberDesc secondInteger) {
		IntegerNumber firstIntegerNumber = new IntegerNumber(firstInteger.getValue());
		IntegerNumber secondIntegerNumber = new IntegerNumber(secondInteger.getValue());
		IntegerNumber result = firstIntegerNumber.add(secondIntegerNumber);
		fireSumOfTwoIntegers(firstIntegerNumber, secondIntegerNumber, result);
	}

	private void fireSumOfTwoIntegers(IntegerNumber firstIntegerNumber, IntegerNumber secondIntegerNumber,
									  IntegerNumber sum) {
		for (SumListener listener : sumListeners) {
			listener.sumCalculated(firstIntegerNumber.getValue(), secondIntegerNumber.getValue(), sum.getValue());
		}
	}
}