package ru.dobrokvashinevgeny.research.mvc.services;

public interface SumListener {
	void sumCalculated(int firstIntegerNumberValue, int secondIntegerNumber, int sumValue);
}