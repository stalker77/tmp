/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvc.services;

public class IntegerNumberDesc {
	private final int value;

	public static IntegerNumberDesc createFromStringValue(String value) throws NumberConvertException {
		try {
			int intValue = Integer.parseInt(value);
			return new IntegerNumberDesc(intValue);
		} catch (NumberFormatException e) {
			throw new NumberConvertException(e);
		}
	}

	public IntegerNumberDesc(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	@Override
	public String toString() {
		return "IntegerNumberDesc{" +
			"value=" + value +
			'}';
	}
}