/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvc.infrastructure.presentation.form;

import ru.dobrokvashinevgeny.research.mvc.services.*;

import java.util.*;

public class AdditionTwoNumbersFormView {
	private static final String FIRST_INPUT = "23";
	private static final String SECOND_INPUT = "-7";

	private List<InputDataListener> listeners = new ArrayList<>();
	private InputDataController controller;
	private NumberService numberService;

	public void addInputDataListener(InputDataListener listener) {
		this.listeners.add(listener);
	}

	public void removeInputDataListener(InputDataListener listener) {
		this.listeners.remove(listener);
	}

	public void show() throws InputDataListenerException {
		System.out.println("Программа сложения 2-ух целых чисел:");

		System.out.print("1-е число: ");
		System.out.println(FIRST_INPUT);

		System.out.print("2-е число: ");
		System.out.println(SECOND_INPUT);

		fireInputDataEntered(FIRST_INPUT, SECOND_INPUT);
	}

	private void fireInputDataEntered(String firstInput, String secondInput) throws InputDataListenerException {
		for (InputDataListener listener : listeners) {
			listener.inputDataEntered(firstInput, secondInput);
		}
	}

	public NumberService getModel() {
		return this.numberService;
	}

	public void setModel(NumberService model) {
		if (this.numberService != null) {
			this.numberService.removeSumOfTwoIntegersListener(modelListener);
		}

		this.numberService = model;

		if (this.numberService != null) {
			this.numberService.addSumOfTwoIntegersListener(modelListener);
		}
	}

	private SumListener modelListener = new SumListener() {
		@Override
		public void sumCalculated(int firstIntegerNumberValue, int secondIntegerNumber, int sumValue) {
			showResult(firstIntegerNumberValue, secondIntegerNumber, sumValue);
		}
	};

	private void showResult(int firstIntegerNumberValue, int secondIntegerNumber, int sumValue) {
		System.out.println("Результат: " + firstIntegerNumberValue + " + " + secondIntegerNumber + " = " + sumValue);
	}

	public void setController(InputDataController controller) {
		if (this.controller != null) {
			this.controller.detach(this);
		}

		this.controller = controller;

		if (this.controller != null) {
			this.controller.attach(this);
		}
	}
}