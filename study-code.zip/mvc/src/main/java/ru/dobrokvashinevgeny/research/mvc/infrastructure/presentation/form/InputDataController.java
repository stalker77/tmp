/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvc.infrastructure.presentation.form;

import ru.dobrokvashinevgeny.research.mvc.services.*;

public class InputDataController implements InputDataListener {
	private AdditionTwoNumbersFormView additionTwoNumbersFormView;

	public void attach(AdditionTwoNumbersFormView additionTwoNumbersFormView) {
		this.additionTwoNumbersFormView = additionTwoNumbersFormView;
		additionTwoNumbersFormView.addInputDataListener(this);
	}

	public void detach(AdditionTwoNumbersFormView additionTwoNumbersFormView) {
		additionTwoNumbersFormView.removeInputDataListener(this);
		this.additionTwoNumbersFormView = null;
	}

	@Override
	public void inputDataEntered(String firstInput, String secondInput) throws InputDataListenerException {
		try {
			IntegerNumberDesc firstNumber = IntegerNumberDesc.createFromStringValue(firstInput);
			IntegerNumberDesc secondNumber = IntegerNumberDesc.createFromStringValue(secondInput);

			final NumberService numberService = this.additionTwoNumbersFormView.getModel();
			numberService.calculateSumOfTwoIntegers(firstNumber, secondNumber);
		} catch (NumberConvertException e) {
			throw new InputDataListenerException(e);
		}
	}
}