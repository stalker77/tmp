package ru.dobrokvashinevgeny.research.mvc.infrastructure.presentation.form;

public interface InputDataListener {
	void inputDataEntered(String firstInput, String secondInput) throws InputDataListenerException;
}