/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvc.infrastructure;

import ru.dobrokvashinevgeny.research.mvc.infrastructure.presentation.form.*;
import ru.dobrokvashinevgeny.research.mvc.services.NumberService;

import java.util.logging.*;

public class ConsoleAppForAdditionTwoNumbers {
	private final static Logger LOG = Logger.getLogger(ConsoleAppForAdditionTwoNumbers.class.getName());
	private final NumberService mainFormModel;
	private final InputDataController mainFormController;
	private final AdditionTwoNumbersFormView mainForm;

	public ConsoleAppForAdditionTwoNumbers() {
		this.mainFormModel = new NumberService();
		this.mainFormController = new InputDataController();
		this.mainForm = createMainForm();
	}

	private AdditionTwoNumbersFormView createMainForm() {
		AdditionTwoNumbersFormView mainForm = new AdditionTwoNumbersFormView();
		mainForm.setModel(mainFormModel);
		mainForm.setController(mainFormController);
		return mainForm;
	}

	public void run() {
		try {
			mainForm.show();
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "", e);
		}
	}
}