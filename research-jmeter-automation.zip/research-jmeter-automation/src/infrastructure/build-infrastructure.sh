#!/bin/bash

/usr/local/packer/packer build /tmp/research-jmeter-automation/infrastructure/service/create-service-docker-image-packer-template.json