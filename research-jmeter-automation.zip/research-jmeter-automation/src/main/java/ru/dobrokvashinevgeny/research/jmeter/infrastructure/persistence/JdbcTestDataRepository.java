/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import ru.dobrokvashinevgeny.research.jmeter.services.TestData;

import javax.sql.DataSource;
import java.sql.*;

public class JdbcTestDataRepository {
	private DataSource dataSource;

	public TestData testDataBy(int testDataId) {
		try(Connection connection = dataSource.getConnection();
			PreparedStatement statement = connection.prepareStatement("select id from testtable where id = ?")) {

			statement.setInt(1, testDataId);
			try(ResultSet resultSet = statement.executeQuery()) {

				if (resultSet.next()) {
					return new TestData(resultSet.getInt("ID"));
				} else {
					return new TestData(-1);
				}
			}
		} catch (SQLException e) {
			return null;
		}
	}

	public void putTestData(TestData testData) {

	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
}