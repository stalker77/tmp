create table TestData (
	ID int not null primary key
);