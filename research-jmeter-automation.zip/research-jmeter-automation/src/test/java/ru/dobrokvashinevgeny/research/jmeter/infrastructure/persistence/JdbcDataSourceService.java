/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import javax.sql.DataSource;
import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class JdbcDataSourceService {
	private static final String QUERY_SEPARATOR = ";";
	private static final String EMPTY_QUERY = "";
	private static final String TAB_STR = "\t";

	private final DataSourceDesc dataSourceDesc;

	public JdbcDataSourceService(DataSourceDesc dataSourceDesc) {
		this.dataSourceDesc = dataSourceDesc;
	}

	public void runSqlScriptOnDataSourceBy(String sqlScriptName) throws JdbcDataSourceServiceException {
		List<String> queriesToRun = getQueriesToRunFromScriptBy(sqlScriptName);

		try (Connection connection = getDataSource().getConnection();
			Statement statement = connection.createStatement()) {
			connection.setAutoCommit(false);

			for (String query : queriesToRun) {
				try {
					statement.executeUpdate(query);
				} catch (SQLException e) {
					connection.rollback();

					throw new JdbcDataSourceServiceException(e);
				}
			}

			connection.commit();
		} catch (SQLException e) {
			throw new JdbcDataSourceServiceException(e);
		}
	}

	private List<String> getQueriesToRunFromScriptBy(String sqlScriptName) throws JdbcDataSourceServiceException {
		ClassLoader classLoader = getClass().getClassLoader();
		final URL sqlScriptResource = classLoader.getResource(sqlScriptName);
		if (sqlScriptResource == null) {
			throw new JdbcDataSourceServiceException("Sql script file: " + sqlScriptName + " - not exists!");
		}

		StringBuilder sqlScriptBuilder = new StringBuilder();
		try(BufferedReader sqlScriptReader = Files.newBufferedReader(Paths.get(sqlScriptResource.getFile()))) {
			String scriptLine;
			while ((scriptLine = sqlScriptReader.readLine()) != null) {
				sqlScriptBuilder.append(scriptLine);
			}
		} catch (IOException e) {
			throw new JdbcDataSourceServiceException(e);
		}

		List<String> queriesToRun = new ArrayList<>();
		String[] splittedQueries = sqlScriptBuilder.toString().split(QUERY_SEPARATOR);
		for (String query : splittedQueries) {
			if (!query.equals(EMPTY_QUERY) && !query.equals(TAB_STR)) {
				queriesToRun.add(query);
			}
		}
		return queriesToRun;
	}

	public DataSource getDataSource() {
		return new FakeDataSource(
			dataSourceDesc.getDataSourceUrl(),
			dataSourceDesc.getDataSourceUser(),
			dataSourceDesc.getDataSourcePassword()
		);
	}
}