/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import java.util.Objects;

public class DataSourceDesc {
	private final String dataSourceUrl;
	private final String dataSourceUser;
	private final String dataSourcePassword;

	public DataSourceDesc(String dataSourceUrl, String dataSourceUser, String dataSourcePassword) {

		this.dataSourceUrl = dataSourceUrl;
		this.dataSourceUser = dataSourceUser;
		this.dataSourcePassword = dataSourcePassword;
	}

	public String getDataSourceUrl() {
		return dataSourceUrl;
	}

	public String getDataSourceUser() {
		return dataSourceUser;
	}

	public String getDataSourcePassword() {
		return dataSourcePassword;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		DataSourceDesc that = (DataSourceDesc) o;
		return getDataSourceUrl().equals(that.getDataSourceUrl()) &&
			getDataSourceUser().equals(that.getDataSourceUser()) &&
			getDataSourcePassword().equals(that.getDataSourcePassword());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getDataSourceUrl(), getDataSourceUser(), getDataSourcePassword());
	}

	@Override
	public String toString() {
		return "DataSourceDesc{" +
			"dataSourceUrl='" + dataSourceUrl + '\'' +
			", dataSourceUser='" + dataSourceUser + '\'' +
			", dataSourcePassword='" + dataSourcePassword + '\'' +
			'}';
	}
}