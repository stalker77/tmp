/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.util.Properties;

public class DataSourceDescProducer {
	public DataSourceDesc produceDataSourceDescBy(String dataSourceUrlsConfigFileName, String dataSourcePropertyName)
		throws DataSourceDescProducerException {
		ClassLoader classLoader = getClass().getClassLoader();
		final URL dataSourceUrlsConfigFileResource = classLoader.getResource(dataSourceUrlsConfigFileName);
		if (dataSourceUrlsConfigFileResource == null) {
			throw new DataSourceDescProducerException("DataSource urls config file: " + dataSourceUrlsConfigFileName
				+ " - not exists!");
		}

		Properties dataSourceDescConfig = new Properties();
		try(InputStream dataSourceDescConfigStream = Files.newInputStream(
			Paths.get(dataSourceUrlsConfigFileResource.getFile()))
		) {
			dataSourceDescConfig.load(dataSourceDescConfigStream);

			return new DataSourceDesc(
				dataSourceDescConfig.getProperty(dataSourcePropertyName + ".url"),
				dataSourceDescConfig.getProperty(dataSourcePropertyName + ".userLogin"),
				dataSourceDescConfig.getProperty(dataSourcePropertyName + ".userPassword")
			);
		} catch (IOException e) {
			throw new DataSourceDescProducerException(e);
		}
	}
}