/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.jmeter.services.TestData;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

//@EnabledIfSystemProperty(named = "tests.runIntegration", matches = "true")
class JdbcTestDataRepositoryIntegrationTest {
	private static final String DATA_SOURCE_URLS_CONFIG_FILE_NAME = "dataSourceUrls.properties";
	private static final String DATA_SOURCE_URL_PROPERTY_NAME = "dataSource";
	private static final String REMOVE_SCHEME_SQL_SCRIPT_NAME = "removeScheme.sql";
	private static final String CREATE_SCHEME_SQL_SCRIPT_NAME = "createScheme.sql";
	private static final String CLEAN_UP_DATA_SQL_SCRIPT_NAME = "cleanUpData.sql";
	private static JdbcDataSourceService DATA_SOURCE_SERVICE;
	private static final int TEST_DATA_ID = 123;

	@BeforeAll
	static void setupDataBaseScheme() throws Exception {
		DataSourceDesc dataSourceDesc =
			new DataSourceDescProducer()
				.produceDataSourceDescBy(DATA_SOURCE_URLS_CONFIG_FILE_NAME, DATA_SOURCE_URL_PROPERTY_NAME);

		DATA_SOURCE_SERVICE
			= new JdbcDataSourceService(dataSourceDesc);

		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(REMOVE_SCHEME_SQL_SCRIPT_NAME);

		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(CREATE_SCHEME_SQL_SCRIPT_NAME);
	}

	@BeforeEach
	void setUp() throws Exception {
		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(CLEAN_UP_DATA_SQL_SCRIPT_NAME);
	}

	@Test
	void successfullyGetSavedData() {
		JdbcTestDataRepository testRepository = new JdbcTestDataRepository();
		testRepository.setDataSource(DATA_SOURCE_SERVICE.getDataSource());

		testRepository.putTestData(new TestData(TEST_DATA_ID));

		TestData expectedTestData = new TestData(TEST_DATA_ID);


		TestData testData = testRepository.testDataBy(TEST_DATA_ID);


		assertThat(testData, equalTo(expectedTestData));
	}
}