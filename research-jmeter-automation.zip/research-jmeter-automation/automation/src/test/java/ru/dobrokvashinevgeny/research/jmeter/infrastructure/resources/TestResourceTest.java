/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.resources;

import org.junit.jupiter.api.Test;

class TestResourceTest {
	@Test
	void name() {
	}
}