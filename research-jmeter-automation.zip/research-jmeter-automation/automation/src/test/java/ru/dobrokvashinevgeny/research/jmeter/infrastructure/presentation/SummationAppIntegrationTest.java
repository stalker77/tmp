/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.presentation;

import org.junit.jupiter.api.*;

import java.io.*;
import java.nio.charset.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

class SummationAppIntegrationTest {
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final String EXPECTED_SUM_DISPLAYED_IN_THE_CONSOLE =
		FIRST_ADDEND + " + " + SECOND_ADDEND + " = " + (FIRST_ADDEND + SECOND_ADDEND) + "\n";
	private static final String[] EMPTY_ARGS = {};
	private static final Charset CONSOLE_CHARSET = StandardCharsets.UTF_8;
	private ByteArrayOutputStream console;

	@BeforeEach
	void setUp() {
		console = new ByteArrayOutputStream();

		setSystemConsoleTo(console);
	}

	private void setSystemConsoleTo(ByteArrayOutputStream console) {
		System.setOut(new PrintStream(console));
	}

	@Test
	void outputSumOfTwoNumbersToConsole() {
		SummationApp.setFirstAddend(FIRST_ADDEND);
		SummationApp.setSecondAddend(SECOND_ADDEND);


		SummationApp.main(EMPTY_ARGS);


		assertThat(getDisplayedDataFromConsoleAsString(console, CONSOLE_CHARSET),
			equalTo(EXPECTED_SUM_DISPLAYED_IN_THE_CONSOLE));
	}

	private String getDisplayedDataFromConsoleAsString(ByteArrayOutputStream console, Charset consoleCharset) {
		return new String(console.toByteArray(), consoleCharset);
	}
}