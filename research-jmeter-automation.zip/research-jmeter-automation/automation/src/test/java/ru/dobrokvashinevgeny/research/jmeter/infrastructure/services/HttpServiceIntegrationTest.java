/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.services;

import org.apache.catalina.startup.*;
import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.jmeter.services.ServiceInfo;

import java.net.URI;
import java.nio.file.*;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

//@EnabledIfSystemProperty(named = "tests.runIntegration", matches = "true")
class HttpServiceIntegrationTest {
	private static final String INTEGRATION_TESTS_CONFIG_FILE_NAME = "integrationTestsConfig.properties";
	private static final String WEB_SERVICE_PROPERTY_NAME = "service";
	private static Tomcat tomcatServer;
	private static int tomcatServerPort;

	@BeforeAll
	static void startService() throws Exception {
		WebServiceDesc webServiceDesc = new WebServiceDescProducer(
			new ConfigLoaderFromPropertiesFile()
		).produceWebServiceDescBy(INTEGRATION_TESTS_CONFIG_FILE_NAME, WEB_SERVICE_PROPERTY_NAME);

		tomcatServerPort = webServiceDesc.getServicePort();

		tomcatServer = createTomcatServerBy(webServiceDesc);

		tomcatServer.start();
	}

	private static Tomcat createTomcatServerBy(WebServiceDesc webServiceDesc) throws Exception {
		tomcatServer = new Tomcat();
		tomcatServer.setPort(webServiceDesc.getServicePort());
		Files.createDirectories(Paths.get(webServiceDesc.getServiceBaseDir() + "/webapps"));
		tomcatServer.setBaseDir(webServiceDesc.getServiceBaseDir());
		tomcatServer.getServer().addLifecycleListener(new VersionLoggerListener());
		tomcatServer.addWebapp(tomcatServer.getHost(), webServiceDesc.getServiceContextPath(),
			webServiceDesc.getPathToServiceWarFile());

		return tomcatServer;
	}

	@AfterAll
	static void stopService() throws Exception {
		tomcatServer.stop();

		tomcatServer.destroy();

	}

	@Test
	void successfullyGetInfoByValidParameters() {
		HttpService httpService = new HttpService();
		httpService.setServiceUri(URI.create("http://localhost:" + tomcatServerPort + "/http-service"));
		ServiceInfo expectedServiceInfo = new ServiceInfo("test1");


		ServiceInfo serviceInfo = httpService.getInfo(new ValidParams());


		assertThat(serviceInfo, equalTo(expectedServiceInfo));
	}

	@Test
	void name() {
		new ee().e();

	}

	private static class ee {
		public Integer e(){
			return 0;
		}
	}
}