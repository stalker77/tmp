/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.jmeter.infrastructure.services.ConfigLoaderFromPropertiesFile;
import ru.dobrokvashinevgeny.research.jmeter.services.TestData;

import java.math.BigInteger;
import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

//@EnabledIfSystemProperty(named = "tests.runIntegration", matches = "true")
class JdbcTestDataRepositoryIntegrationTest {
	private static final String INTEGRATION_TESTS_CONFIG_FILE_NAME = "integrationTestsConfig.properties";
	private static final String DATA_SOURCE_URL_PROPERTY_NAME = "dataSource";
	private static final String REMOVE_SCHEME_SQL_SCRIPT_NAME = "removeScheme.sql";
	private static final String CREATE_SCHEME_SQL_SCRIPT_NAME = "createScheme.sql";
	private static final String CLEAN_UP_DATA_SQL_SCRIPT_NAME = "cleanUpData.sql";
	private static JdbcDataSourceService DATA_SOURCE_SERVICE;
	private static final int TEST_DATA_ID = 123;

	@BeforeAll
	static void setupDataBaseScheme() throws Exception {
		DataSourceDesc dataSourceDesc = new DataSourceDescProducer(
			new ConfigLoaderFromPropertiesFile()
		).produceDataSourceDescBy(INTEGRATION_TESTS_CONFIG_FILE_NAME, DATA_SOURCE_URL_PROPERTY_NAME);

		DATA_SOURCE_SERVICE
			= new JdbcDataSourceService(dataSourceDesc);

		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(REMOVE_SCHEME_SQL_SCRIPT_NAME);

		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(CREATE_SCHEME_SQL_SCRIPT_NAME);
	}

	@AfterAll
	static void removeDataBaseScheme() throws Exception {
		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(REMOVE_SCHEME_SQL_SCRIPT_NAME);
	}

	@BeforeEach
	void setUp() throws Exception {
		DATA_SOURCE_SERVICE.runSqlScriptOnDataSourceBy(CLEAN_UP_DATA_SQL_SCRIPT_NAME);
	}

	@Test
	void successfullyGetSavedData() {
		JdbcTestDataRepository testRepository = new JdbcTestDataRepository();
		testRepository.setDataSource(DATA_SOURCE_SERVICE.getDataSource());

		testRepository.putTestData(new TestData(TEST_DATA_ID));

		TestData expectedTestData = new TestData(TEST_DATA_ID);


		TestData testData = testRepository.testDataBy(TEST_DATA_ID);


		assertThat(testData, equalTo(expectedTestData));
	}

	@Test
	void name() {
		BigInteger fibonacciNumber = getMinFibonacciNumberGreaterThan(BigInteger.valueOf(10946));

		System.out.println(fibonacciNumber);
	}

	private BigInteger getMinFibonacciNumberGreaterThan(BigInteger n) {
		BigInteger firstPriorNumber = BigInteger.valueOf(0);
		BigInteger secondPriorNumber = BigInteger.valueOf(1);
		BigInteger resultNumber = BigInteger.valueOf(0);

		while(resultNumber.compareTo(n) <= 0) {
			resultNumber = firstPriorNumber.add(secondPriorNumber);

			firstPriorNumber = secondPriorNumber;
			secondPriorNumber = resultNumber;
		}

		return resultNumber;
	}

	@Test
	void name1() {
		showAllPrimesLessThan(100);
	}

	private void showAllPrimesLessThan(int n) {
		boolean[] primeCandidates = new boolean[n + 1];

		initializePrimeCandidates(primeCandidates);

		for (int primeCandidateCounter = 2; primeCandidateCounter < primeCandidates.length; ++primeCandidateCounter) {
			if (primeCandidates[primeCandidateCounter]) {
				for (int multiplicityFactor = 2;
					 primeCandidateCounter * multiplicityFactor < primeCandidates.length;
					 ++multiplicityFactor) {
					primeCandidates[primeCandidateCounter * multiplicityFactor] = false;
				}
			}
		}

		showPrimesFrom(primeCandidates);
	}

	private void initializePrimeCandidates(boolean[] primesCandidates) {
		Arrays.fill(primesCandidates, true);

		primesCandidates[0] = false;
		primesCandidates[1] = false;
	}

	private void showPrimesFrom(boolean[] primeCandidates) {
		for(int primeCandidateCounter = 0; primeCandidateCounter < primeCandidates.length; primeCandidateCounter++) {
			if (primeCandidates[primeCandidateCounter]) {
				System.out.println(primeCandidateCounter);
			}
		}
	}
}