/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.services;

import java.util.Properties;

public class WebServiceDescProducer {
	private final ConfigLoaderFromPropertiesFile configLoaderFromPropertiesFile;

	public WebServiceDescProducer(ConfigLoaderFromPropertiesFile configLoaderFromPropertiesFile) {
		this.configLoaderFromPropertiesFile = configLoaderFromPropertiesFile;
	}

	public WebServiceDesc produceWebServiceDescBy(String webServicesConfigFileName, String webServicePropertyName)
		throws WebServiceDescProducerException {
		Properties webServicesConfig = new Properties();
		try {
			configLoaderFromPropertiesFile.loadConfigBy(webServicesConfig, webServicesConfigFileName);
		} catch (ConfigLoaderFromPropertiesFileException e) {
			throw new WebServiceDescProducerException(e);
		}

		return new WebServiceDesc(
			Integer.valueOf(webServicesConfig.getProperty("webserver.port")),
			webServicesConfig.getProperty("webserver.basedir"),
			webServicesConfig.getProperty(webServicePropertyName + ".contextPath"),
			webServicesConfig.getProperty(webServicePropertyName + ".pathToWarFile")
		);
	}
}