/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.services;

import java.util.Objects;

public class WebServiceDesc {
	private final int servicePort;
	private final String serviceBaseDir;
	private final String serviceContextPath;
	private final String pathToServiceWarFile;

	public WebServiceDesc(int servicePort, String serviceBaseDir, String serviceContextPath,
						  String pathToServiceWarFile) {
		this.servicePort = servicePort;
		this.serviceBaseDir = serviceBaseDir;
		this.serviceContextPath = serviceContextPath;
		this.pathToServiceWarFile = pathToServiceWarFile;
	}

	public int getServicePort() {
		return servicePort;
	}

	public String getServiceBaseDir() {
		return serviceBaseDir;
	}

	public String getServiceContextPath() {
		return serviceContextPath;
	}

	public String getPathToServiceWarFile() {
		return pathToServiceWarFile;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		WebServiceDesc that = (WebServiceDesc) o;
		return getServicePort() == that.getServicePort() &&
			getServiceBaseDir().equals(that.getServiceBaseDir()) &&
			getServiceContextPath().equals(that.getServiceContextPath()) &&
			getPathToServiceWarFile().equals(that.getPathToServiceWarFile());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getServicePort(), getServiceBaseDir(), getServiceContextPath(), getPathToServiceWarFile());
	}

	@Override
	public String toString() {
		return "WebServiceDesc{" +
			"servicePort=" + servicePort +
			", serviceBaseDir='" + serviceBaseDir + '\'' +
			", serviceContextPath='" + serviceContextPath + '\'' +
			", pathToServiceWarFile='" + pathToServiceWarFile + '\'' +
			'}';
	}
}