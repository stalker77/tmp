/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import ru.dobrokvashinevgeny.research.jmeter.infrastructure.services.*;

import java.util.Properties;

public class DataSourceDescProducer {
	private final ConfigLoaderFromPropertiesFile configLoaderFromPropertiesFile;

	public DataSourceDescProducer(ConfigLoaderFromPropertiesFile configLoaderFromPropertiesFile) {
		this.configLoaderFromPropertiesFile = configLoaderFromPropertiesFile;
	}

	public DataSourceDesc produceDataSourceDescBy(String dataSourceUrlsConfigFileName, String dataSourcePropertyName)
		throws DataSourceDescProducerException {
		Properties dataSourceDescConfig = new Properties();
		try {
			configLoaderFromPropertiesFile.loadConfigBy(dataSourceDescConfig, dataSourceUrlsConfigFileName);
		} catch (ConfigLoaderFromPropertiesFileException e) {
			throw new DataSourceDescProducerException(e);
		}

		return new DataSourceDesc(
			dataSourceDescConfig.getProperty(dataSourcePropertyName + ".url"),
			dataSourceDescConfig.getProperty(dataSourcePropertyName + ".userLogin"),
			dataSourceDescConfig.getProperty(dataSourcePropertyName + ".userPassword")
		);
	}
}