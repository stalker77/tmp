/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.services;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.util.Properties;

public class ConfigLoaderFromPropertiesFile {
	public void loadConfigBy(Properties config, String configFileName) throws ConfigLoaderFromPropertiesFileException {
		ClassLoader classLoader = getClass().getClassLoader();
		final URL configFileResource = classLoader.getResource(configFileName);
		if (configFileResource == null) {
			throw new ConfigLoaderFromPropertiesFileException("Config file: " + configFileName
				+ " - not exists!");
		}

		try(InputStream configStream = Files.newInputStream(
			Paths.get(configFileResource.getFile()))
		) {
			config.load(configStream);
		} catch (IOException e) {
			throw new ConfigLoaderFromPropertiesFileException(e);
		}
	}
}