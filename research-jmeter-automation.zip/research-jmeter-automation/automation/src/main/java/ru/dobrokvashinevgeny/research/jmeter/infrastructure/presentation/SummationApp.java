/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.presentation;

public class SummationApp {
	private static int firstAddend = 3;
	private static int secondAddend = 5;

	public static void main(String[] args) {
		final int sumOfAddends = getSumOfAddends(firstAddend, secondAddend);

		displaySumOfAddendsToConsole(sumOfAddends);
	}

	private static int getSumOfAddends(int firstAddend, int secondAddend) {
		return firstAddend + secondAddend;
	}

	private static void displaySumOfAddendsToConsole(int sumOfAddends) {
		System.out.println(firstAddend + " + " + secondAddend + " = " + sumOfAddends);
	}

	static void setFirstAddend(int firstAddend) {
		SummationApp.firstAddend = firstAddend;
	}

	static void setSecondAddend(int secondAddend) {
		SummationApp.secondAddend = secondAddend;
	}
}