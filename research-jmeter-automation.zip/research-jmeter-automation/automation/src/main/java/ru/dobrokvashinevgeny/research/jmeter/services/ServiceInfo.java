/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.services;

import java.util.Objects;

public class ServiceInfo {
	private final String test;

	public ServiceInfo(String test) {
		this.test = test;
	}

	public String getTest() {
		return test;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		ServiceInfo that = (ServiceInfo) o;
		return getTest().equals(that.getTest());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTest());
	}

	@Override
	public String toString() {
		return "ServiceInfo{" +
			"test='" + test + '\'' +
			'}';
	}
}