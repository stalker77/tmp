/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.services;

import java.util.Objects;

public class TestData {
	private final int testDataId;

	public TestData(int testDataId) {
		this.testDataId = testDataId;
	}

	public int getTestDataId() {
		return testDataId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		TestData testData = (TestData) o;
		return getTestDataId() == testData.getTestDataId();
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTestDataId());
	}

	@Override
	public String toString() {
		return "TestData{" +
			"testDataId=" + testDataId +
			'}';
	}
}