/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.services;

import java.util.Objects;

public class JaxbServiceInfo {
	private String test;

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		JaxbServiceInfo that = (JaxbServiceInfo) o;
		return getTest().equals(that.getTest());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTest());
	}

	@Override
	public String toString() {
		return "JaxbServiceInfo{" +
			"test='" + test + '\'' +
			'}';
	}
}