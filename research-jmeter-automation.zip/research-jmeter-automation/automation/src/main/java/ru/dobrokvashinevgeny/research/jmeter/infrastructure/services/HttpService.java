/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.services;

import ru.dobrokvashinevgeny.research.jmeter.services.ServiceInfo;

import javax.ws.rs.client.*;
import javax.ws.rs.core.MediaType;
import java.net.URI;

public class HttpService {
	private URI serviceUri;

	public ServiceInfo getInfo(ValidParams validParams) {
		Client client = ClientBuilder.newClient();
		JaxbServiceInfo jaxbServiceInfo =
			client.target(serviceUri)
				.path("rest")
				.request(MediaType.APPLICATION_JSON)
				.get(JaxbServiceInfo.class);

		return new ServiceInfo(jaxbServiceInfo.getTest());
	}

	public void setServiceUri(URI serviceUri) {
		this.serviceUri = serviceUri;
	}
}