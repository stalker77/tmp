/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.jmeter.infrastructure.persistence;

import ru.dobrokvashinevgeny.research.jmeter.services.TestData;

import javax.sql.DataSource;
import java.sql.*;

public class JdbcTestDataRepository {
	private DataSource dataSource;

	public TestData testDataBy(int testDataId) {
		try(Connection connection = dataSource.getConnection();
			PreparedStatement statement = connection.prepareStatement("select id from TestData where id = ?")) {

			statement.setInt(1, testDataId);
			try(ResultSet resultSet = statement.executeQuery()) {

				if (resultSet.next()) {
					return new TestData(resultSet.getInt("ID"));
				} else {
					return new TestData(-1);
				}
			}
		} catch (SQLException e) {
			return null;
		}
	}

	public void putTestData(TestData testData) {
		try(Connection connection = dataSource.getConnection();
			PreparedStatement statement = connection.prepareStatement("insert into TestData(id) values (?)")) {
			statement.setInt(1, testData.getTestDataId());

			statement.executeUpdate();
		} catch (SQLException e) {
		}
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
}