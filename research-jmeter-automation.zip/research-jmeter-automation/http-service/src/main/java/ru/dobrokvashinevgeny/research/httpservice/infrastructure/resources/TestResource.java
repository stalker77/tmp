/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.httpservice.infrastructure.resources;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/")
public class TestResource {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String test() {
		return "{\"test\":\"test1\"}";
	}
}