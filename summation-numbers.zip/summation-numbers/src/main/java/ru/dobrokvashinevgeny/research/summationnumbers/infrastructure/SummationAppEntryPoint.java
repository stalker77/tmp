/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.summationnumbers.infrastructure;

import ru.dobrokvashinevgeny.research.summationnumbers.services.*;

public class SummationAppEntryPoint {
	private static int firstAddend = 3;
	private static int secondAddend = 5;
	private static SummationAppService summationAppService;

	public static void main(String[] args) {
		SummationAppService summationAppService = summationAppService();

		summationAppService.outputSumOfTwoNumbersToConsole(firstAddend, secondAddend);
	}

	private static SummationAppService summationAppService() {
		return (summationAppService == null)
			? new SummationAppService(new SummationService(), new ConsoleDisplayService())
			: summationAppService;
	}

	static void setFirstAddend(int firstAddend) {
		SummationAppEntryPoint.firstAddend = firstAddend;
	}

	static void setSecondAddend(int secondAddend) {
		SummationAppEntryPoint.secondAddend = secondAddend;
	}

	static void setSummationAppService(SummationAppService summationAppService) {
		SummationAppEntryPoint.summationAppService = summationAppService;
	}
}