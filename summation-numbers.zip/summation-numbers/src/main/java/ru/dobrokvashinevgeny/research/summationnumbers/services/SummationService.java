/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.summationnumbers.services;

public class SummationService {
	public int getSumOfAddends(int firstAddend, int secondAddend) {
		return firstAddend + secondAddend;
	}
}