/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.summationnumbers.infrastructure;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.summationnumbers.services.*;

import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.mock;

class SummationAppEntryPointTest {
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final String[] EMPTY_ARGS = {};

	@Test
	void outputSumOfTwoNumbersToConsole() {
		SummationAppService summationAppService = mock(SummationAppService.class);
		SummationAppEntryPoint.setSummationAppService(summationAppService);

		SummationAppEntryPoint.setFirstAddend(FIRST_ADDEND);
		SummationAppEntryPoint.setSecondAddend(SECOND_ADDEND);


		SummationAppEntryPoint.main(EMPTY_ARGS);


		then(summationAppService).should().outputSumOfTwoNumbersToConsole(FIRST_ADDEND, SECOND_ADDEND);
	}

	@AfterEach
	void tearDown() {
		SummationAppEntryPoint.setSummationAppService(null);
	}
}