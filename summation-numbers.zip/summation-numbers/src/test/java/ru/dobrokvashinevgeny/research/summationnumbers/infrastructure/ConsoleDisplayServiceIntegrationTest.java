package ru.dobrokvashinevgeny.research.summationnumbers.infrastructure;

import org.junit.jupiter.api.*;

import java.io.*;
import java.nio.charset.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

class ConsoleDisplayServiceIntegrationTest {
	private static final Charset CONSOLE_CHARSET = StandardCharsets.UTF_8;
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final int SUM_OF_ADDENDS = FIRST_ADDEND + SECOND_ADDEND;
	private static final String EXPECTED_SUM_DISPLAYED_IN_THE_CONSOLE =
		FIRST_ADDEND + " + " + SECOND_ADDEND + " = " + SUM_OF_ADDENDS + "\n";

	private ByteArrayOutputStream console;

	private void setSystemConsoleTo(ByteArrayOutputStream console) {
		System.setOut(new PrintStream(console));
	}

	@BeforeEach
	void setUp() {
		console = new ByteArrayOutputStream();

		setSystemConsoleTo(console);
	}

	@Test
	void outputFormattedSumOfTwoNumbersToConsole() {
		ConsoleDisplayService consoleDisplayService = new ConsoleDisplayService();


		consoleDisplayService.showSumOfAddends(FIRST_ADDEND, SECOND_ADDEND, SUM_OF_ADDENDS);


		assertThat(getDisplayedDataFromConsoleAsString(console, CONSOLE_CHARSET),
			equalTo(EXPECTED_SUM_DISPLAYED_IN_THE_CONSOLE));
	}

	private String getDisplayedDataFromConsoleAsString(ByteArrayOutputStream console, Charset consoleCharset) {
		return new String(console.toByteArray(), consoleCharset);
	}
}