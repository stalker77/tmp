/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.summationnumbers.infrastructure;

import ru.dobrokvashinevgeny.research.summationnumbers.services.DisplayService;

public class ConsoleDisplayService implements DisplayService {
	@Override
	public void showSumOfAddends(int firstAddend, int secondAddend, int sumOfAddends) {
		System.out.println(firstAddend + " + " + secondAddend + " = " + sumOfAddends);
	}
}