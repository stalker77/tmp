/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.summationnumbers.services;

public class SummationAppService {
	private final SummationService summationService;
	private final DisplayService displayService;

	public SummationAppService(SummationService summationService, DisplayService displayService) {
		this.summationService = summationService;
		this.displayService = displayService;
	}

	public void outputSumOfTwoNumbersToConsole(int firstAddend, int secondAddend) {
		final int sumOfAddends = summationService.getSumOfAddends(firstAddend, secondAddend);

		displayService.showSumOfAddends(firstAddend, secondAddend, sumOfAddends);
	}
}