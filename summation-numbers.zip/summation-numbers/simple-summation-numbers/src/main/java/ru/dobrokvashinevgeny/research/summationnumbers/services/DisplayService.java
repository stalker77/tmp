package ru.dobrokvashinevgeny.research.summationnumbers.services;

public interface DisplayService {
	void showSumOfAddends(int firstAddend, int secondAddend, int sumOfAddends);
}