package ru.dobrokvashinevgeny.research.summationnumbers.services;

import org.junit.jupiter.api.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

class SummationServiceTest {
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final int EXPECTED_SUM_OF_ADDENDS = FIRST_ADDEND + SECOND_ADDEND;

	@Test
	void returnSumOfAddends() {
		var summationService = new SummationService();


		int sumOfAddends = summationService.getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND);


		assertThat(sumOfAddends, equalTo(EXPECTED_SUM_OF_ADDENDS));
	}
}