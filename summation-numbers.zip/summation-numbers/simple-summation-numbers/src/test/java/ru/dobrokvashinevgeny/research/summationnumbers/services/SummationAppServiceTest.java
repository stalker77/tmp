package ru.dobrokvashinevgeny.research.summationnumbers.services;

import org.junit.jupiter.api.Test;

import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.mock;

class SummationAppServiceTest {
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final int SUM_OF_ADDENDS = FIRST_ADDEND + SECOND_ADDEND;

	@Test
	void outputSumOfTwoNumbersToConsole() {
		var summationService = mock(SummationService.class);
		given(summationService.getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND)).willReturn(SUM_OF_ADDENDS);

		var displayService = mock(DisplayService.class);
		var summationAppService = new SummationAppService(summationService, displayService);


		summationAppService.outputSumOfTwoNumbersToConsole(FIRST_ADDEND, SECOND_ADDEND);


		then(displayService).should().showSumOfAddends(FIRST_ADDEND, SECOND_ADDEND, SUM_OF_ADDENDS);
	}
}