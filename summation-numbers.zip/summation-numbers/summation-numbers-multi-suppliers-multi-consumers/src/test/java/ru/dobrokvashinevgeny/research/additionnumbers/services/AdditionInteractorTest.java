package ru.dobrokvashinevgeny.research.additionnumbers.services;

import org.junit.jupiter.api.*;
import ru.dobrokvashinevgeny.research.additionnumbers.services.addend.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.*;
import static org.mockito.Mockito.mock;

class AdditionInteractorTest {
	private static final int FIRST_ADDEND = 1;
	private static final int SECOND_ADDEND = 2;
	private static final int SUM_OF_ADDENDS = FIRST_ADDEND + SECOND_ADDEND;
	private static final String SUPPLIER_DESC = "Supplier";
	private static final String CONSUMER_DESC = "Consumer";

	private AddendSupplier addendSupplier;
	private AdditionService additionService;
	private DisplayMessageService displayMessageService;
	private SumConsumer sumConsumer;

	@BeforeEach
	void setUp() {
		addendSupplier = mock(AddendSupplier.class);
		additionService = mock(AdditionService.class);
		displayMessageService = mock(DisplayMessageService.class);
		sumConsumer = mock(SumConsumer.class);
	}

	@Test
	void sendToSumConsumerSumOfAddendsProducedByAddendSupplier() throws Exception {
		given(addendSupplier.produceAddends()).willReturn(new AddendsDesc(FIRST_ADDEND, SECOND_ADDEND));
		given(addendSupplier.getSupplierDesc()).willReturn(SUPPLIER_DESC);

		given(additionService.getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND)).willReturn(SUM_OF_ADDENDS);

		given(sumConsumer.getConsumerDesc()).willReturn(CONSUMER_DESC);

		var additionInteractor = new AdditionInteractor(addendSupplier, additionService,
			sumConsumer, displayMessageService);


		additionInteractor.sendToSumConsumerSumOfAddendsProducedByAddendSupplier();


		then(addendSupplier).should().produceAddends();
		then(additionService).should().getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND);
		then(displayMessageService)
			.should().showAddendSupplierProduceAddendsMessage(SUPPLIER_DESC, FIRST_ADDEND, SECOND_ADDEND);
		then(displayMessageService)
			.should().showSumConsumerConsumeSumOfAddendsMessage(CONSUMER_DESC, SUM_OF_ADDENDS);
		then(sumConsumer).should().consume(FIRST_ADDEND, SECOND_ADDEND, SUM_OF_ADDENDS);
	}

	@Test
	void throwExceptionWhenAddendSupplierFail() throws Exception {
		given(addendSupplier.produceAddends()).willThrow(AddendSupplierException.class);

		given(additionService.getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND)).willReturn(SUM_OF_ADDENDS);

		var additionInteractor = new AdditionInteractor(addendSupplier, additionService,
			sumConsumer, displayMessageService);


		assertThrows(
			AdditionInteractorException.class,
			additionInteractor::sendToSumConsumerSumOfAddendsProducedByAddendSupplier
		);
	}

	@Test
	void throwExceptionWhenDisplayMessageServiceFail() throws Exception {
		given(addendSupplier.produceAddends()).willReturn(new AddendsDesc(FIRST_ADDEND, SECOND_ADDEND));
		given(addendSupplier.getSupplierDesc()).willReturn(SUPPLIER_DESC);

		willThrow(DisplayMessageServiceException.class)
			.given(displayMessageService)
			.showAddendSupplierProduceAddendsMessage(SUPPLIER_DESC, FIRST_ADDEND, SECOND_ADDEND);

		var additionInteractor = new AdditionInteractor(addendSupplier, additionService,
			sumConsumer, displayMessageService);


		assertThrows(
			AdditionInteractorException.class,
			additionInteractor::sendToSumConsumerSumOfAddendsProducedByAddendSupplier
		);
	}

	@Test
	void throwExceptionWhenDisplayMessageServiceAnotherFail() throws Exception {
		given(addendSupplier.produceAddends()).willReturn(new AddendsDesc(FIRST_ADDEND, SECOND_ADDEND));
		given(addendSupplier.getSupplierDesc()).willReturn(SUPPLIER_DESC);

		given(additionService.getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND)).willReturn(SUM_OF_ADDENDS);

		given(sumConsumer.getConsumerDesc()).willReturn(CONSUMER_DESC);

		willThrow(DisplayMessageServiceException.class)
			.given(displayMessageService)
			.showSumConsumerConsumeSumOfAddendsMessage(CONSUMER_DESC, SUM_OF_ADDENDS);

		var additionInteractor = new AdditionInteractor(addendSupplier, additionService,
			sumConsumer, displayMessageService);


		assertThrows(
			AdditionInteractorException.class,
			additionInteractor::sendToSumConsumerSumOfAddendsProducedByAddendSupplier
		);
	}

	@Test
	void throwExceptionWhenSumConsumerFail() throws Exception {
		given(addendSupplier.produceAddends()).willReturn(new AddendsDesc(FIRST_ADDEND, SECOND_ADDEND));
		given(addendSupplier.getSupplierDesc()).willReturn(SUPPLIER_DESC);

		given(additionService.getSumOfAddends(FIRST_ADDEND, SECOND_ADDEND)).willReturn(SUM_OF_ADDENDS);

		willThrow(SumConsumerException.class).given(sumConsumer).consume(FIRST_ADDEND, SECOND_ADDEND, SUM_OF_ADDENDS);

		var additionInteractor = new AdditionInteractor(addendSupplier, additionService,
			sumConsumer, displayMessageService);


		assertThrows(
			AdditionInteractorException.class,
			additionInteractor::sendToSumConsumerSumOfAddendsProducedByAddendSupplier
		);
	}
}