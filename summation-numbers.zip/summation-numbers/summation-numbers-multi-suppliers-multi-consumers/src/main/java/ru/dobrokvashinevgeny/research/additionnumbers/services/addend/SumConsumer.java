package ru.dobrokvashinevgeny.research.additionnumbers.services.addend;

public interface SumConsumer {
	void consume(int firstAddend, int secondAddend, int sumOfAddends) throws SumConsumerException;

	String getConsumerDesc();
}