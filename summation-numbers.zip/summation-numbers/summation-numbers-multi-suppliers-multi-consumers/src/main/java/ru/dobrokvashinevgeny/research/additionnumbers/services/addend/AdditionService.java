/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.additionnumbers.services.addend;

public class AdditionService {
	public int getSumOfAddends(int firstAddend, int secondAddend) {
		return 0;
	}
}