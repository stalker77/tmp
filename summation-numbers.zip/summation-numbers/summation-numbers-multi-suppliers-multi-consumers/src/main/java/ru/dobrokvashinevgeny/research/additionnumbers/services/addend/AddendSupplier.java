package ru.dobrokvashinevgeny.research.additionnumbers.services.addend;

public interface AddendSupplier {
	AddendsDesc produceAddends() throws AddendSupplierException;

	String getSupplierDesc();
}