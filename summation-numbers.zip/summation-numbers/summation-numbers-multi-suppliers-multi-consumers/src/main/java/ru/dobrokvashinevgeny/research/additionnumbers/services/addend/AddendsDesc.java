/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.additionnumbers.services.addend;

import java.util.Objects;

public class AddendsDesc {
	private final int firstAddend;
	private final int secondAddend;

	public AddendsDesc(int firstAddend, int secondAddend) {
		this.firstAddend = firstAddend;
		this.secondAddend = secondAddend;
	}

	public int getFirstAddend() {
		return firstAddend;
	}

	public int getSecondAddend() {
		return secondAddend;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		AddendsDesc that = (AddendsDesc) o;
		return getFirstAddend() == that.getFirstAddend() &&
			getSecondAddend() == that.getSecondAddend();
	}

	@Override
	public int hashCode() {
		return Objects.hash(getFirstAddend(), getSecondAddend());
	}

	@Override
	public String toString() {
		return "AddendsDesc{" +
			"firstAddend=" + firstAddend +
			", secondAddend=" + secondAddend +
			'}';
	}
}