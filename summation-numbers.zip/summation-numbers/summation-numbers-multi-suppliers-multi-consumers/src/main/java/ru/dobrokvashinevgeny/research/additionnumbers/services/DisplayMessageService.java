package ru.dobrokvashinevgeny.research.additionnumbers.services;

public interface DisplayMessageService {
	void showAddendSupplierProduceAddendsMessage(String supplierDesc, int firstAddend, int secondAddend)
		throws DisplayMessageServiceException;

	void showSumConsumerConsumeSumOfAddendsMessage(String consumerDesc, int sumOfAddends)
		throws DisplayMessageServiceException;
}