/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.additionnumbers.services;

import org.slf4j.*;
import ru.dobrokvashinevgeny.research.additionnumbers.services.addend.*;

public class AdditionInteractor {
	private static final Logger LOG = LoggerFactory.getLogger(AdditionInteractor.class);

	private final AddendSupplier addendSupplier;
	private final AdditionService additionService;
	private final SumConsumer sumConsumer;
	private final DisplayMessageService displayMessageService;

	public AdditionInteractor(AddendSupplier addendSupplier, AdditionService additionService,
							  SumConsumer sumConsumer, DisplayMessageService displayMessageService) {
		this.addendSupplier = addendSupplier;
		this.additionService = additionService;
		this.sumConsumer = sumConsumer;
		this.displayMessageService = displayMessageService;
	}

	public void sendToSumConsumerSumOfAddendsProducedByAddendSupplier() throws AdditionInteractorException {
		LOG.trace("Begin sendToSumConsumerSumOfAddendsProducedByAddendSupplier()");

		try {
			AddendsDesc addends = addendSupplier.produceAddends();
			final int firstAddend = addends.getFirstAddend();
			final int secondAddend = addends.getSecondAddend();
			final String supplierDesc = addendSupplier.getSupplierDesc();
			LOG.debug("Supplier produced addends: {} from: {}", addends, supplierDesc);

			displayMessageService.showAddendSupplierProduceAddendsMessage(supplierDesc, firstAddend, secondAddend);

			int sumOfAddends = additionService.getSumOfAddends(firstAddend, secondAddend);
			LOG.debug("Received sum of addends: {}", sumOfAddends);

			sumConsumer.consume(firstAddend, secondAddend, sumOfAddends);
			final String consumerDesc = sumConsumer.getConsumerDesc();
			LOG.debug("Sum of addends: {} successfully consumed by: {}.", sumOfAddends, consumerDesc);

			displayMessageService.showSumConsumerConsumeSumOfAddendsMessage(consumerDesc, sumOfAddends);
		} catch (AddendSupplierException | DisplayMessageServiceException | SumConsumerException e) {
			throw new AdditionInteractorException(e);
		} finally {
			LOG.trace("End sendToSumConsumerSumOfAddendsProducedByAddendSupplier()");
		}
	}
}