package ru.dobrokvashinevgeny.research.mvpgxt.client.services;

import com.google.gwt.http.client.*;
import com.google.gwt.json.client.*;
import ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.GwtRestClientFactory;

import java.util.*;

public class NumberService {
	private List<SumListener> sumListeners;

	public NumberService() {
		sumListeners = new ArrayList<>();
	}

	public void addSumOfTwoIntegersListener(SumListener listener) {
//		sumListeners.add(listener);
	}

	public void calculateSumOfTwoIntegers(IntegerNumberDesc firstNumber, IntegerNumberDesc secondNumber) {
		RequestBuilder request = GwtRestClientFactory.createPostRequest("");
		try {
			request.sendRequest(toNumberValuesAsJsonString(firstNumber, secondNumber), new RequestCallback() {
				@Override
				public void onResponseReceived(Request request, Response response) {
//					controller.onReceiveModel(toComponentApplication(response.getText()));
				}

				@Override
				public void onError(Request request, Throwable exception) {
//					controller.onReceiveModelError(new AppModelException(exception));
				}
			});
		} catch (RequestException e) {
//			controller.onReceiveModelError(new AppModelException(e));
		}
	}

	private String toNumberValuesAsJsonString(IntegerNumberDesc firstNumber, IntegerNumberDesc secondNumber) {
		JSONNumber firstNumberJson = new JSONNumber(firstNumber.getValue());
		JSONNumber secondNumberJson = new JSONNumber(secondNumber.getValue());
		JSONObject numberValuesObject = new JSONObject();
		numberValuesObject.put("firstNumber", firstNumberJson);
		numberValuesObject.put("secondNumber", secondNumberJson);
		return numberValuesObject.toString();
	}
}