/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure;

import ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.GxtEnvironment;
import ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.form.GxtAdditionTwoNumbersFormView;
import ru.dobrokvashinevgeny.research.mvpgxt.client.interfaceadapters.*;
import ru.dobrokvashinevgeny.research.mvpgxt.client.services.NumberService;

import java.util.logging.*;

public class GxtAppForAdditionTwoNumbers {
	private final static Logger LOG = Logger.getLogger(GxtAppForAdditionTwoNumbers.class.getName());
	private final FormPresenter mainFormPresenter;
	private final AdditionTwoNumbersFormView mainForm;

	public GxtAppForAdditionTwoNumbers() {
		this.mainForm = new GxtAdditionTwoNumbersFormView(new GxtEnvironment());
		this.mainFormPresenter = new FormPresenter(mainForm, new NumberService());
	}

	public void run() {
		try {
			mainForm.show();
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "", e);
		}
	}
}