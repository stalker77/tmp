/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure;

public class Applications {
	public static GxtAppForAdditionTwoNumbers createApp() {
		return new GxtAppForAdditionTwoNumbers();
	}
}