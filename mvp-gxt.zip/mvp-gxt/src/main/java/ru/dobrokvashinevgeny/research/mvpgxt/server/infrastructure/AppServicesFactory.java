/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.server.infrastructure;

import ru.dobrokvashinevgeny.research.mvpgxt.server.services.NumberService;

public class AppServicesFactory {
	public static NumberService createNumberService() {
		return new NumberService();
	}
}