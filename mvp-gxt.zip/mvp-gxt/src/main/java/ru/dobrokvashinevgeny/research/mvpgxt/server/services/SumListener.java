package ru.dobrokvashinevgeny.research.mvpgxt.server.services;

public interface SumListener {
	void sumCalculated(int sumValue);
}