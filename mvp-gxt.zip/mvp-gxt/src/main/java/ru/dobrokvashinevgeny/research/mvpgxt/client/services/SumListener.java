package ru.dobrokvashinevgeny.research.mvpgxt.client.services;

public interface SumListener {
	void sumCalculated(int sumValue);
}