package ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.form;

public interface InputDataListener {
	void inputDataEntered() throws InputDataListenerException;
}