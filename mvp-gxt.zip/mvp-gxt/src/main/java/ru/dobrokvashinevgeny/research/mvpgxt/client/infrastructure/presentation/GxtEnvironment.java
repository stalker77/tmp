/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation;

import com.google.gwt.user.client.ui.*;
import com.sencha.gxt.widget.core.client.container.Viewport;

public class GxtEnvironment {
	private com.sencha.gxt.widget.core.client.container.Viewport currentViewport;

	public GxtEnvironment() {
		this.currentViewport = new Viewport();
	}

	public void setCurrentViewportWidget(Widget widget) {
		currentViewport.setWidget(widget);
	}

	public void showCurrentViewport() {
		RootPanel.get().add(currentViewport);
	}
}