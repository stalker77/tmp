/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.form;

import com.google.gwt.user.client.ui.VerticalPanel;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.form.*;
import ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.GxtEnvironment;
import ru.dobrokvashinevgeny.research.mvpgxt.client.interfaceadapters.AdditionTwoNumbersFormView;

import java.util.*;

public class GxtAdditionTwoNumbersFormView implements AdditionTwoNumbersFormView {
	private final GxtEnvironment environment;
	private final FramedPanel form;
	private final VerticalPanel internalLayoutContainer;
	private IntegerField firstNumberInputField;
	private IntegerField secondNumberInputField;
	private TextButton getResult;
	private List<InputDataListener> listeners = new ArrayList<>();

	public GxtAdditionTwoNumbersFormView(GxtEnvironment environment) {
		this.environment = environment;
		form = new FramedPanel();
		internalLayoutContainer = new VerticalPanel();
		form.add(internalLayoutContainer, new MarginData(20));
		form.setHeading("Программа сложения 2-ух целых чисел");

		firstNumberInputField = createNumberInputField("Введите 1-е число");
		secondNumberInputField = createNumberInputField("Введите 2-е число");
		getResult = createGetResultButton();
	}

	private IntegerField createNumberInputField(String prompt) {
		final IntegerField numberInputField = new IntegerField();
		FieldLabel numberInputFieldLabel = new FieldLabel(numberInputField, prompt);
		internalLayoutContainer.add(numberInputFieldLabel);
		return numberInputField;
	}

	private TextButton createGetResultButton() {
		final TextButton button = new TextButton("Сложить числа", resultHandler);
		internalLayoutContainer.add(button);
		return button;
	}

	private SelectHandler resultHandler = new SelectHandler() {
		@Override
		public void onSelect(SelectEvent event) {
			try {
				fireInputDataEntered();
			} catch (InputDataListenerException e) { /* NOP */ }
		}
	};

	private void fireInputDataEntered() throws InputDataListenerException {
		for (InputDataListener listener : listeners) {
			listener.inputDataEntered();
		}
	}

	@Override
	public void addInputDataListener(InputDataListener listener) {
		this.listeners.add(listener);
	}

	@Override
	public void removeInputDataListener(InputDataListener listener) {
		this.listeners.remove(listener);
	}

	@Override
	public String getFirstInputValue() {
		return firstNumberInputField.getText();
	}

	@Override
	public String getSecondInputValue() {
		return secondNumberInputField.getText();
	}

	@Override
	public void show() throws InputDataListenerException, InputDataException {
		environment.setCurrentViewportWidget(form);
		environment.showCurrentViewport();
	}

	@Override
	public void setResult(int sumValue) {

	}
}