package ru.dobrokvashinevgeny.research.mvpgxt.client.interfaceadapters;

import ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation.form.*;

public interface AdditionTwoNumbersFormView {
	void addInputDataListener(InputDataListener listener);

	void removeInputDataListener(InputDataListener listener);

	String getFirstInputValue();

	String getSecondInputValue();

	void show() throws InputDataListenerException, InputDataException;

	void setResult(int sumValue);
}