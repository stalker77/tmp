/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.server.infrastructure.resources;

import ru.dobrokvashinevgeny.research.mvpgxt.server.infrastructure.AppServicesFactory;
import ru.dobrokvashinevgeny.research.mvpgxt.server.services.*;

import javax.ws.rs.*;

@Path("/numbers")
public class NumbersResource implements SumListener {
	@POST
	public void calculateSumOfTwoIntegers(int firstInteger, int secondInteger) {
		NumberService numberService = AppServicesFactory.createNumberService();
		numberService.addSumOfTwoIntegersListener(this);
		IntegerNumberDesc firstNumber = new IntegerNumberDesc(firstInteger);
		IntegerNumberDesc secondNumber = new IntegerNumberDesc(secondInteger);
		numberService.calculateSumOfTwoIntegers(firstNumber, secondNumber);
	}

	@Override
	public void sumCalculated(int sumValue) {

	}
}