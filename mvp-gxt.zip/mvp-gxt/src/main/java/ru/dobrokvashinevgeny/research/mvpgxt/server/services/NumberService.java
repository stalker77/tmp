/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.server.services;

import ru.dobrokvashinevgeny.research.mvpgxt.server.domain.model.IntegerNumber;

import java.util.*;

public class NumberService {
	private final List<SumListener> sumListeners;

	public NumberService() {
		this.sumListeners = new ArrayList<>();
	}

	public void addSumOfTwoIntegersListener(SumListener listener) {
		sumListeners.add(listener);
	}

	public void removeSumOfTwoIntegersListener(SumListener listener) {
		sumListeners.remove(listener);
	}

	public void calculateSumOfTwoIntegers(IntegerNumberDesc firstInteger, IntegerNumberDesc secondInteger) {
		IntegerNumber firstIntegerNumber = new IntegerNumber(firstInteger.getValue());
		IntegerNumber secondIntegerNumber = new IntegerNumber(secondInteger.getValue());
		IntegerNumber result = firstIntegerNumber.add(secondIntegerNumber);
		fireSumOfTwoIntegers(result);
	}

	private void fireSumOfTwoIntegers(IntegerNumber sum) {
		for (SumListener listener : sumListeners) {
			listener.sumCalculated(sum.getValue());
		}
	}
}