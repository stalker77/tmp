/*
 * Copyright (c) 2018 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.presentation;

import com.google.gwt.core.client.EntryPoint;
import ru.dobrokvashinevgeny.research.mvpgxt.client.infrastructure.*;

public class MainEntryPoint implements EntryPoint {
	@Override
	public void onModuleLoad() {
		GxtAppForAdditionTwoNumbers application = Applications.createApp();
		application.run();
	}
}