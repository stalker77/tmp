package ru.dobrokvashinevgeny.research.jwt.infrastructure;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.junit.jupiter.api.Test;

class JwtTest {
	private static final String SECRET = "secret";

	@Test
	void name() {
		Algorithm algorithmHS = Algorithm.HMAC512(SECRET);

		String token = JWT.create()
			.withIssuer("")
			.sign(algorithmHS);

		System.out.println(token);

		DecodedJWT jwt = JWT.decode(token);
		System.out.println(jwt.getHeader());
	}
}