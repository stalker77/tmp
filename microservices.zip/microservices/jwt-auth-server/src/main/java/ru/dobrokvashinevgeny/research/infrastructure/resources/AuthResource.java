/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.infrastructure.resources;

import javax.enterprise.inject.Produces;

@Path("auth")
public class AuthResource {
	@POST
	@Produces()
	public void authenticate() {

	}

	@Path("refresh")
	@POST
	public void refreshAuthentiacation() {

	}
}