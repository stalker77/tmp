/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.thorntail.infrastructure.resources;

public class JaxbResult {
	private boolean result;

	private String resultString;

	public JaxbResult() {
	}

	public JaxbResult(boolean result, String resultString) {
		this.result = result;
		this.resultString = resultString;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public String getResultString() {
		return resultString;
	}

	public void setResultString(String resultString) {
		this.resultString = resultString;
	}
}