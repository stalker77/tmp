/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.thorntail.infrastructure.presentation;

public class HealthServiceCheck /*implements HealthCheck*/ {
}