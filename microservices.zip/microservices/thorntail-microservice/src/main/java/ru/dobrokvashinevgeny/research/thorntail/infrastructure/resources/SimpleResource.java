/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.thorntail.infrastructure.resources;

import javax.ws.rs.*;

@Path("/")
public class SimpleResource {
	@GET
	@Produces("text/plain")
	public String getString() {
		return "Hello from Thorntail JAX-RS!!!";
	}
}