/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.thorntail.infrastructure.resources;

import org.slf4j.*;
import ru.dobrokvashinevgeny.research.thorntail.infrastructure.services.ConfigurationPropertyWithName;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/")
public class SimpleResource {
	private static final Logger LOG = LoggerFactory.getLogger(SimpleResource.class);

	@Inject @ConfigurationPropertyWithName(propertyName = "test")
	private String text;

	@GET
	@Produces(MediaType.APPLICATION_JSON + ";" + MediaType.CHARSET_PARAMETER + "=UTF-8;")
	public JaxbResult getString() {
		LOG.info("Hello from logger))");

		return new JaxbResult(true, text);
	}
}