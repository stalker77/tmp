/*
 * Copyright (c) 2019 Evgeny Dobrokvashin, All Rights Reserved.
 */

package ru.dobrokvashinevgeny.research.thorntail.infrastructure.services;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;


@ApplicationScoped
public class TextProducer {
	@Produces @ConfigurationPropertyWithName(propertyName = "test")
	public String getText() {
		return "Hello from Thorntail with Jax-rs and CDI!!!";
	}
}